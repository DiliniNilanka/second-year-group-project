<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">   




<?php if($this->session->userdata('ss_status')) { ?>


<!-- navigation bar for admin(General Manager) -->

 <?php 
           
           if ($this->session->userdata('ss_user_level') == 1) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('order/initial_order_list_view')?>">
                          <i class="icon_piechart"></i>
                          <span>Generate Purches Order</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>
    
    
     <?php 
           
           if ($this->session->userdata('ss_user_level') == 1)
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('order/po_list_view')?>">
                          <i class="icon_piechart"></i>
                          <span>List Purches Order</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>

<?php 
           
           if ($this->session->userdata('ss_user_level') == 1) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('Register_controller')?>">
                          <i class="icon_piechart"></i>
                          <span>Register users</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>  

<?php 
           
           if ($this->session->userdata('ss_user_level') == 1) 
           {?>
<br>
<br>

<?php } 
          
?>


<!-- nevigation bar for Main Store -->


<?php 
           
           if ($this->session->userdata('ss_user_level') == 1)
           {?>
            
           <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class=""></i>
                          <span><strong><center>Main Store</center></strong></span>
                          
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
  <?php 
           
           if (($this->session->userdata('ss_user_level') == 2) || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('store');?>">
                          <i class="icon_piechart"></i>
                          <span>View Stock Data</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>     


<?php 
           
           if ($this->session->userdata('ss_user_level') == 2 ) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('grn/grn_list_view');?>">
                          <i class="icon_piechart"></i>
                          <span>Update Stock Levels</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>                 
<?php 
           
           if ($this->session->userdata('ss_user_level') == 2) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('grn/grn_list_view')?>">
                          <i class="icon_piechart"></i>
                          <span>List GRN</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?> 
                  
                  
                  
                  
                  

                

                
                  
                  
              
 <?php 
					 
					 if ($this->session->userdata('ss_user_level') == 2 ) 
					 {?>
   					
					
                   <li>                     
                      <a class="" href="<?php echo base_url('order')?>">
                          <i class="icon_piechart"></i>
                          <span>Generate Order</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
					
?>
    




<?php 
           
           if ($this->session->userdata('ss_user_level') == 2  || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('view_request_controller/initial_order_list_view') ?>">
                          <i class="icon_piechart"></i>
                          <span>View Requests</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>
    
    
    
                 

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <?php 
					 
					 if ($this->session->userdata('ss_user_level') == 2  || ($this->session->userdata('ss_user_level') == 1)) 
					 {?>
   					
					
                   <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Wastage Managment</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
					
?>
                  
       
       
        <?php 
					 
					 if ($this->session->userdata('ss_user_level') == 2  || ($this->session->userdata('ss_user_level') == 1)) 
					 {?>
   					
					
                    <li>                     
                      <a class="" href="<?php echo base_url('helpc');?>">
                          <i class="icon_piechart"></i>
                          <span>Help</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
					
?>               </ul>
                  </li> 
                   
                    
                    
                    <?php } 
          
          
?>

<?php 
           
           if ($this->session->userdata('ss_user_level') == 1) 
           {?>
<br>

<?php } 
          
?>



<?php 
           
           if ($this->session->userdata('ss_user_level') == 1)
           {?>
            
           <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class=""></i>
                          <span><strong><center>Restaurant</center></strong></span>
                          
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">


<!-- nevigation bar for restaurent -->

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3  || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('restaurant_mini_store_view_controller')?>">
                          <i class="icon_piechart"></i>
                          <span>View Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>  


 <?php 
           
           if ((($this->session->userdata('ss_user_level') == 3) && ($this->session->userdata('ss_position') == 'Restaurant Head'))) 
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Update Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>  

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('restaurant_mini_store_order_controller');?>">
                          <i class="icon_piechart"></i>
                          <span>Order Request</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('rest_issue_items_cntrl'); ?>">
                          <i class="icon_piechart"></i>
                          <span>Issue Items</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3 || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('rest_issue_log_cntrl');?>">
                          <i class="icon_piechart"></i>
                          <span>View Issue Log</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3 || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Wastage Managment</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3 || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Help</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>       </ul>
                  </li> 
                   
                    
                    
                    <?php } 
          
          
?>
             
<?php 
           
           if ($this->session->userdata('ss_user_level') == 1) 
           {?>
<br>

<?php } 
          
?>

<?php 
           
           if ($this->session->userdata('ss_user_level') == 1)
           {?>
            
           <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class=""></i>
                          <span><strong><center>Kitchen</center></strong></span>
                          
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">

<!-- navigation bar for Kitchen -->

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4 || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_ministore_view_controller'); ?>">
                          <i class="icon_piechart"></i>
                          <span>View Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

 <?php 
           
           if ((($this->session->userdata('ss_user_level') == 4) && ($this->session->userdata('ss_position') == 'Head Chef'))) 
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Update Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>  

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_critical_level_new_controller'); ?>">
                          <i class="icon_piechart"></i>
                          <span>Order Request</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4 ) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_issue_items_cntrl'); ?>">
                          <i class="icon_piechart"></i>
                          <span>Issue Items</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4 || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_issue_log_cntrl');?>">
                          <i class="icon_piechart"></i>
                          <span>View Issue Log</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4 || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Wastage Managment</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4 || ($this->session->userdata('ss_user_level') == 1)) 
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Help</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>              
              </ul>
                  </li> 
                   
                    
                    
                    <?php } 
          
          
?>


<!-- From here to down is the nevigation for the second and third levels(main store level and kitchen/restaurant) -->




                                            <!-- Main store -->
<?php 
           
           if ($this->session->userdata('ss_user_level') == 2) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('store');?>">
                          <i class="icon_piechart"></i>
                          <span>View Stock Data</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>     


<?php 
           
           if ($this->session->userdata('ss_user_level') == 2 )
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('grn/grn_list_view');?>">
                          <i class="icon_piechart"></i>
                          <span>Update Stock Levels</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>                  
                  
         <?php 
           
           if ($this->session->userdata('ss_user_level') == 2) 
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('grn/grn_list_view')?>">
                          <i class="icon_piechart"></i>
                          <span>List GRN</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>          
                  
                  
                  

                

                
                  
                  
              
 <?php 
           
           if ($this->session->userdata('ss_user_level') == 2 )
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('order')?>">
                          <i class="icon_piechart"></i>
                          <span>Generate Order</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>
    




<?php 
           
           if ($this->session->userdata('ss_user_level') == 2 )
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('view_request_controller/initial_order_list_view') ?>">
                          <i class="icon_piechart"></i>
                          <span>View Requests</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>
    
    
    
                 

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <?php 
           
           if ($this->session->userdata('ss_user_level') == 2 )
           {?>
            
          
                   <li>                     
                      <a class="" href="<?php echo base_url('Wastagec')?>">
                          <i class="icon_piechart"></i>
                          <span>Wastage Managment</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    <?php } 
          
?>
                  
       
       
        <?php 
           
           if ($this->session->userdata('ss_user_level') == 2 )
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('helpc');?>">
                          <i class="icon_piechart"></i>
                          <span>Help</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>



                          <!-- Restaurant -->


          <?php 
           
           if ($this->session->userdata('ss_user_level') == 3 )
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('restaurant_mini_store_view_controller');?>">
                          <i class="icon_piechart"></i>
                          <span>View Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>  


 <?php 
           
           if (($this->session->userdata('ss_user_level') == 3) && ($this->session->userdata('ss_position') == 'Restaurant Head')) 
           {?>
            
          
                    <li>                     
                      <a class="" href="#">
                          <i class="icon_piechart"></i>
                          <span>Update Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>  

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3 ) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('restaurant_mini_store_order_controller');?>">
                          <i class="icon_piechart"></i>
                          <span>Order Request</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3 ) 
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('rest_issue_items_cntrl'); ?>">
                          <i class="icon_piechart"></i>
                          <span>Issue Items</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3)
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('rest_issue_log_cntrl');?>">
                          <i class="icon_piechart"></i>
                          <span>View Issue Log</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3)
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Wastage Managment</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 3)
           {?>
            
          
                    <li>                     
                      <a class="" href="">
                          <i class="icon_piechart"></i>
                          <span>Help</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>       



                  <!-- kitchen -->


          <?php 
           
           if ($this->session->userdata('ss_user_level') == 4)
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_ministore_view_controller'); ?>">
                          <i class="icon_piechart"></i>
                          <span>View Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

 <?php 
           
           if ((($this->session->userdata('ss_user_level') == 4) && ($this->session->userdata('ss_position') == 'Head Chef')))
           {?>
            
          
                    <li>                     
                      <a class="" href="#">
                          <i class="icon_piechart"></i>
                          <span>Update Stock</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>  

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4)
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_critical_level_new_controller'); ?>">
                          <i class="icon_piechart"></i>
                          <span>Order Request</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4)
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_issue_items_cntrl'); ?>">
                          <i class="icon_piechart"></i>
                          <span>Issue Items</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>


  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4)
           {?>
            
          
                    <li>                     
                      <a class="" href="<?php echo base_url('kitchen_issue_log_cntrl');?>">
                          <i class="icon_piechart"></i>
                          <span>View Issue Log</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4)
           {?>
            
          
                    <li>                     
                      <a class="" href="#">
                          <i class="icon_piechart"></i>
                          <span>Wastage Managment</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>

  <?php 
           
           if ($this->session->userdata('ss_user_level') == 4)
           {?>
            
          
                    <li>                     
                      <a class="" href="#">
                          <i class="icon_piechart"></i>
                          <span>Help</span>
                          
                      </a>
                                         
                  </li>
                    
                    
                    
                      <?php } 
          
?>             
                      
                      
                      
                      <?php } 
				
				
				else
				{
					header('Refresh: 0;url='.base_url('user_authentication/logout'));
					
				}
					
?>              
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                    </p>
                   
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->