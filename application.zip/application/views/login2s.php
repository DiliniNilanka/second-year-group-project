<!DOCTYPE html>
<html>
  <head>
    <title>
      <?php echo "Login";?> |  Job Management System
    </title>
    <?php $this->load->view("common/header"); ?>
    <style type="text/css">
 .txt-box-icon {
  margin-left: 10px;
  margin-top: 10px;
  position: absolute;
}

.background_color { color:
#FFF
}

.padding-left-10 {
	/*padding-left:35px;*/
}
</style>
    <style type="text/css">
	
	.form-control.search-select {
	padding: 0 !important;
	box-shadow: none;
	border: none;
}
.select2-container .select2-choice {
	background-clip: padding-box !important;
	background-color: #FFFFFF !important;
	background-image: none !important;
	background-repeat: no-repeat !important;
	border: 1px solid #CCCCCC !important;
	border-radius: 0 !important;
	box-shadow: none !important;
	color: #555555 !important;
	display: block !important;
	height: 34px !important;
	width:225px;
	line-height: 29px !important;
	margin-top: 3px !important;
	overflow: hidden !important;
	padding: 0 12px 0 8px !important;
	position: relative !important;
	text-decoration: none !important;
	white-space: nowrap !important;
}
	</style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Jobplanet - Responsive Job Board HTML Template </title>

    <!--favicon-->
    
    <link rel="apple-touch-icon" href="assets/theme/images/apple-touch-icon.png">
    <link rel="shortcut icon" href="assets/theme/images/favicon.ico" type="image/x-icon">

    <!-- bootstrap -->
    

   <link href="assets/plugins/bootstrap-3.3.2/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Icons -->
    <link href="assets/plugins/font-awesome-4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- lightbox -->
    <link href="assets/plugins/magnific-popup/magnific-popup.css" rel="stylesheet">
   

    <!-- Themes styles-->
    <link href="assets/theme/css/theme.css" rel="stylesheet">  
    <!-- Your custom css -->
    <link href="assets/theme/css/theme-custom.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo asset_url(); ?>plugins/DataTables/media/css/DT_bootstrap.css" />
    <link href="<?php echo base_url('thems/plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('thems/plugins/bootstrap-modal/css/bootstrap-modal.css'); ?>" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('thems/plugins/select2/select2.css'); ?>" />
<link rel="stylesheet" href="<?php echo base_url("thems/plugins/bootstrap-fileupload/bootstrap-fileupload.min.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url('thems/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('thems/plugins/datepicker/css/datepicker.css'); ?>">
		<link rel="stylesheet" href="<?php echo base_url('thems/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css'); ?>">
		<link rel="stylesheet" href="<?php echo base_url('thems/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css'); ?>">
       <link rel="stylesheet" type="text/css" href="<?php echo base_url('thems/plugins/select2/select2.css'); ?>" /> 
<!--<link rel="stylesheet" href="<?php echo base_url('thems/css/main.css'); ?>">-->
<style type="text/css">
			.table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td, .table-striped thead tr.primary:nth-child(2n+1) th {
			    background-color:#FFF;
			    border-color: #FFF;
			    border: 1px solid #FFF;
			    color: white;
			    text-align: center;
				
			}
           .table thead .sorting_desc {
			 visibility: hidden;  
            }
}
		</style>
  </head>
<body class="page-header-fixed bg-1 layout-boxed">

    <div class="modal-shiftfix">
     
     <?php //$this->load->view("common/main_menu"); ?>
      <div class="container-fluid main-content">
        
       
        <div class="row" style="margin-top: 0">
          <div id="login_bg" class="col-lg-12">
            <div class="widget-container fluid-height clearfix">
            	<!-- page data start -->
                <div  class="col-lg-4" style="margin-left:auto; margin-right:auto; float:none; text-align:center;">
              		<!-- Login Screen -->
    <div class="login-wrapper">
    
    <br>

     <h1><?php echo "Login";?></h1>
     
      <form name="login" id="login" action="#" method="post">
        <div class="form-group">
        <?php if($this->session->flashdata('login_message')){?>
        <div class="alert alert-danger" id="error-msg-div">
                      <button type="button" data-dismiss="alert" class="close">×</button>
                      <?php echo $this->session->flashdata('login_message');?>
                     <!-- Invalid Email or Password. Please try again.-->
                      
                    </div>
                    <?php } ?>
                    <!-- class="col-lg-12"-->
          <div class="text-left">
            
            <input class="form-control padding-left-10" placeholder="Email" type="text" name="user_username" id="user_username" required>
          </div>
        </div>
        <div class="form-group">
          <div class="text-left">
          
           
            <input class="form-control padding-left-10" placeholder="Password" type="password" name="password" id="password" required>
          </div>
        </div>
        <a class="pull-right" href="#">Forgot password?</a>
        <div class="text-left">
          <label class="checkbox"></label>
        </div>
        <input class="btn btn-lg btn-primary btn-block" type="submit" value="Log in" id="login">
        <div class="social-login clearfix hide">
          <a class="btn btn-primary pull-left facebook" href="index.html"><i class="fa fa-facebook"></i>Login with facebook</a><a class="btn btn-primary pull-right twitter" href="index.html"><i class="fa fa-twitter"></i>Login with twitter</a>
        </div>
      </form>
      <p class="hide" >
        Don't have an account yet?
      </p>
      <a  class="btn btn-default-outline btn-block" href="<?php $member_type="c"; echo base_url('register/').'/'.$member_type;?>">Register now</a>
      <br>
<br>

    </div>
    <!-- End Login Screen -->
    </div>
              <!-- page data end -->
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php $this->load->view("common/footer"); ?>
  <script src="assets/plugins/jquery.js"></script>
    <script src="assets/plugins/jquery.easing-1.3.pack.js"></script>    
<script>

   $("#login").submit(function(event) {
        event.preventDefault();
        $("#invalid-pass-error").addClass("hide");
       /*
        if ($("#login").parsley().validate()) {

        } else {
            return false;
        }
        
        */

        // send username and password to php check login
        $.ajax({
            url: "<?php echo base_url(); ?>manage/users/login", data: $(this).serialize(), type: "POST", dataType: 'json',
            success: function(e) {

                if (!e.status) {
                    alert("Invalid email or password!");
                   /// $("#invalid-pass-error").removeClass("hide");
                   //  $("#invalid-pass-error").html(e.msg);
                    //$.notify(e.msg,"error");
                    return false;
                } else {
                    if(e.type=="e"){
                        
                         // window.location.href="<?php echo base_url(); ?>employer/";
                         // if(e.first_login == 1){
                         //   window.location.href="<?php echo base_url(); ?>employer/profile?edit=1";
                      //  }else{
                            window.location.href="<?php echo base_url(); ?>employer/";
                      //  }
                        
                    }else if(e.type=="c"){
                        if(e.first_login == 1){
                            window.location.href="<?php echo base_url(); ?>candidate/profile?edit=1";
                        }else{
                            window.location.href="<?php echo base_url(); ?>candidate/dashboard/";
                        }
                        
                    }
                    else if(e.type=="a"){
                        
                        window.location.href="<?php echo base_url(); ?>admin/profile/";
                    }
                    else{
                        
                         window.location.href="<?php echo base_url(); ?>";
                    }
                    

                    // $.notify(e.msg,"success");
                    //$.notific8(e.msg, {life: 5000, horizontalEdge: "bottom", theme: "success", heading: "SUCCESS!"});

                }


            }
        });

    });

$(document).ready(function(){

	$('#login_bg').css("background-color","#FFF");

//	alert();
	});

</script>
  </body>
</html>