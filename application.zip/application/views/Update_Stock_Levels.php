
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="<?php echo base_url();?>.img/favicon.png">

    <title>Smart KSR system</title>

    <!-- Bootstrap CSS -->    
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="<?php echo base_url();?>css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="<?php echo base_url();?>css/elegant-icons-style.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="<?php echo base_url();?>assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="<?php echo base_url();?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/owl.carousel.css" type="text/css">
	<link href="<?php echo base_url();?>css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link href="<?php echo base_url();?>css/widgets.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/style-responsive.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>css/xcharts.min.css" rel=" stylesheet">	
	<link href="<?php echo base_url();?>css/jquery-ui-1.10.4.min.css" rel="stylesheet">



  </head>

  <body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

 
  <!-- container section start -->
  <section id="container" class="">
     
      <?php $this->load->view('common/header'); ?>
        
    <!--header end-->

      <!--sidebar start-->
      <?php $this->load->view('common/navigation'); ?>
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-home"></i> Update Stock Levels</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-table"></i>Stock</li>
                        <li><i class="fa fa-th-list"></i>Update Stock Levels</li>
												  	
					</ol>
				</div>
			</div>
              
            
		
			
           
			
              
				
			

				</div><!--/col-->
        <div>
            <!--empty space-->
            <br>
        </div>

        <div class="row">
                <div class="col-sm-6">
                    
                        <div class="nav search-row" id="top_menu">
                            <!--  search form start -->
                            <ul class="nav top-menu">                    
                                <li>
                                    <form class="navbar-form">
                                        <input class="form-control" placeholder="Search" type="text" name="term">

                                    </form>
                                </li>                    
                            </ul>
                            <!--  search form end -->                
                        </div>
                        
                </div>
            
                
                    <br>
                    <br>
                    <br>
                    <br>
                    

                
            </div>
            
            <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                              Selected Item
                          </header>
                          
                          <table class="table table-striped table-advance table-hover" id="table1">
                           <thead>
                              <tr>
                                 <th><i class=""></i> Item ID</th>
                                 <th><i class=""></i> Item Name</th>
                                 <th><i class=""></i> Currunt Quantity</th>
                                 <th>
                                  <div class="btn-group">
                                      <a class="btn btn-primary" href="#"><i class="icon_plus_alt2"></i></a>
                                  </div>
                                  </th>
                              </tr>
                              </thead>
                              <tbody>

                              
                                                            
                           </tbody>
                        </table>
                      </section>
                  </div>
              </div>

              <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                              Selected Item
                          </header>
                          
                          <table class="table table-striped table-advance table-hover" id="table2">
                           <thead>
                              <tr>
                                 <th><i class=""></i> Item ID</th>
                                 <th><i class=""></i> Item Name</th>
                                 <th><i class=""></i> Currunt Quantity</th>
                                 
                              </tr>
                              </thead>
                              <tbody>
                       
                           </tbody>
                        </table>
                        
                          
                          </section>
                        
                  </div>
              </div>
				

                    


      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->

  <!-- mine -->
  
                             
  
    <script type="text/javascript" src="<?php echo base_url();?>js/jquery.min.js"></script>

    <!-- javascripts -->
    <script src="<?php echo base_url();?>js/jquery.js"></script>
	<script src="<?php echo base_url();?>js/jquery-ui-1.10.4.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="<?php echo base_url();?>js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="<?php echo base_url();?>assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="<?php echo base_url();?>js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="<?php echo base_url();?>js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	<script src="<?php echo base_url();?>assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="<?php echo base_url();?>js/calendar-custom.js"></script>
	<script src="<?php echo base_url();?>js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="<?php echo base_url();?>js/jquery.customSelect.min.js" ></script>
	<script src="<?php echo base_url();?>assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="<?php echo base_url();?>js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="<?php echo base_url();?>js/sparkline-chart.js"></script>
    <script src="<?php echo base_url();?>js/easy-pie-chart.js"></script>
	<script src="<?php echo base_url();?>js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="<?php echo base_url();?>js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="<?php echo base_url();?>js/xcharts.min.js"></script>
	<script src="<?php echo base_url();?>js/jquery.autosize.min.js"></script>
	<script src="<?php echo base_url();?>js/jquery.placeholder.min.js"></script>
	<script src="<?php echo base_url();?>js/gdp-data.js"></script>	
	<script src="<?php echo base_url();?>js/morris.min.js"></script>
	<script src="<?php echo base_url();?>js/sparklines.js"></script>	
	<script src="<?php echo base_url();?>js/charts.js"></script>
	<script src="<?php echo base_url();?>js/jquery.slimscroll.min.js"></script>
  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});
	
	
	
	 $(document).ready(function() {
                                  var items = [];

                                  $("#table1 tr").on("click", function() {
                                    var newTr = $(this).closest("tr").clone();

                                    var newButtonHTML = "";
                                    $(newButtonHTML).children("button").click(function(e) {
                                    });

                                    $(newTr).children("td:last").html("").html(newButtonHTML);
                                    items.push(newTr);
                                    newTr.appendTo($("#table2"));

                                  });
                          })
						
  

  </script>

  </body>
</html>
