<!DOCTYPE html>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Smart KSR system</title>
    
    
		<link rel="stylesheet" href="<?php echo base_url('plugins/DataTables/media/css/DT_bootstrap.css')?>"/>
		<link href="<?php echo base_url('plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css')?>"  rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url('plugins/bootstrap-modal/css/bootstrap-modal.css')?>"  rel="stylesheet" type="text/css"/>
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-fileupload/bootstrap-fileupload.min.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/select2/select2.css')?>">


		
		<link rel="stylesheet" href="<?php echo base_url('plugins/datepicker/css/datepicker.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-daterangepicker/daterangepicker-bs3.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css') ?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/jQuery-Tags-Input/jquery.tagsinput.css')?>" >
		
		<link rel="stylesheet" href="<?php echo base_url('plugins/summernote/build/summernote.css')?>" >
        
        

		<style type="text/css">
			.table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td, .table-striped thead tr.primary:nth-child(2n+1) th {
			    background-color: #428bca;
			    border-color: #357ebd;
			    border-top: 1px solid #357ebd;
			    color: white;
			    text-align: center;
			}
			
			.modal {
  
	margin:auto;
	
	
   
}


			

		</style>
    
   


    <!-- Bootstrap CSS -->    
  <link href="<?php echo base_url()?>css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="<?php echo base_url()?>css/bootstrap-theme.css"  rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="<?php echo base_url()?>css/elegant-icons-style.css"  rel="stylesheet" />
    <link href="<?php echo base_url()?>css/font-awesome.min.css"  rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="<?php echo base_url()?>assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css"  rel="stylesheet" />
	<link href="<?php echo base_url()?>assets/fullcalendar/fullcalendar/fullcalendar.css"  rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="<?php echo base_url()?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css"  rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url()?>css/owl.carousel.css" type="text/css">
	<link href="<?php echo base_url()?>css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="<?php echo base_url()?>css/fullcalendar.css" >
	<link href="<?php echo base_url()?>css/widgets.css"  rel="stylesheet">
    <link href="<?php echo base_url()?>css/style.css"  rel="stylesheet">
    <link href="<?php echo base_url()?>css/style-responsive.css"  rel="stylesheet" />
	<link href="<?php echo base_url()?>css/xcharts.min.css"  rel=" stylesheet">	
 <link rel="stylesheet" href="<?php echo base_url(); ?>css/jquery-ui.css">


  </head>

  <body>

     
  <!-- container section start -->
  <section id="container" class="">
     
      
    <section id="container" class="">
     
      <?php $this->load->view('common/header'); ?>
        
    <!--header end-->

      <!--sidebar start-->
      <?php $this->load->view('common/navigation'); ?>
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              
              
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-home"></i> Order</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-table"></i>Stock</li>
                        <li><i class="fa fa-th-list"></i>Initial Order</li>
												  	
					</ol>
				</div>
			</div>
     
            </section>
           
            
            
            
            
            
            
            <!--order part stared-->
            
            
            
            
            
            
            
            
            <!-- item add box-->
            <form id="initioal_order_form" name="initioal_order_form">
            
                                        <div id="sticker" class="col-md-12">
											<div class="well well-sm">
												<div class="form-group">
                                        <!-- auto complete start -->
                                        	<div class="input-group wide-tip">
													<div style="padding-left: 10px; padding-right: 10px;" class="input-group-addon">
														<i class="fa fa-2x fa-barcode addIcon"></i>
													</div>
                                                    
													<input type="text" placeholder="Please add products to order list" id="add_item" class="form-control input-lg" value="" name="add_item" onClick="add_items()" style="border-radius: 6px;font-size: 18px;height: 46px;line-height: 1.33;padding: 10px 16px;">
														
												</div>
                                        <!-- end auto complete end -->
                                                
                                               
											</div>


											<div class="clearfix"></div>
											<div class="control-group table-group">
												<label class="table-label">Order Items</label>
													<div class="controls table-controls">
                                                   
                                                    
														<table class="table items table-striped table-bordered table-condensed table-hover" id="soTable">
															<thead>
																<tr>
                                                                <th class="col-md-1">No</th>
																	<th class="col-md-6">Product Name (Product Code)</th>
																	<th class="col-md-2">Stock QTY</th>
																	<th class="col-md-2"> Required Quantity</th>
                                                                    
																	
																	
																	<th class="col-md-1 text-right">
                                                                    </th>
																	<th style="width: 30px !important; text-align: center;"><i class="fa fa-trash-o"></i></th>
																</tr>
															</thead>
																	<tbody>
                                                               
                                                                    
<tr data-item-id="144680019784" class="row_144680019784" id="row_1446800197032">
																			<td>

</td>
																			<td class="text-right">

</td>
																			<td>
																				
</td>
																			<td class="text-right">
																				
</td>
																			<td class="text-right">
																			
</td>
																			
																			<td class="text-center">
														
</td>
																	  </tr>
                                                                        
                                                                        
                                                                       
																	</tbody>
															<tfoot>
															
                                                                 
																	
																</tr>
                                                                <tr class="tfoot active" id="tfoot">
																	<th colspan="4" class="text-right">Total QTY</th>
																	<th class="text-right"><span id="Subtotal">0.00</span></th>
																	
																</tr>
                                                             
															</tfoot>
														</table>
                                                        
                                                        
                                                        <!-- start list -->
                                                        <!-- end list -->
													</div>
											  </div>
											</div>
                                        <!-- end item add box-->

<div id="extras-con" class="row">
</div>

								
                                        
                        </div> 
                        </tfoot>
                        
                       
                        
                        <div class="col-md-12">
                        <div class="modal-footer" style="margin-bottom:10px;">
            				
                            
                            <input type="submit" class="btn btn-primary" value="Save" name="initial_order" id="initial_order">
                             <button id="reset" class="btn btn-danger" type="button">Reset</button>
            			</div>
                        </div>
                        
                       
                       
                      
                        <input name="rowCount" type="hidden" id="rowCount" value="0">
                         
                           
                           <input name="base_url" type="hidden" id="base_url" value="<?php echo base_url();?>">
                          
                   		 </form>
									
							<!-- end: DYNAMIC TABLE PANEL -->
            		<div id="ajax-modal" class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" style="display: none;"></div>

		<!-- end ajax model -->

        <!-- start popup box-->

        <div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-hidden="true">

    <div class="modal-content">

        <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">

        &times;

        </button>

        <h4 class="modal-title">Confirm</h4>

        </div>

        <div class="modal-body">

        <p id="label">

        

        </p>

        </div>

        <div class="modal-footer">

        <input id="sel_id" type="hidden"/>

        <input id="page" type="hidden"/>

        <input id="popup_type" type="hidden"/>

        <button aria-hidden="true" data-dismiss="modal" class="btn btn-default">

        Close

        </button>

        <button id="conirm" class="btn btn-default" data-dismiss="modal">

        Confirm

        </button>

        </div>

        </div>

    </div>

    </div> 
            
          
            
          
		
			<!--order part end-->
           
			
              
				
			
          

          </section> 

      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->
  
  
  
  
  
    
    <!-- javascripts -->

     <script src="<?php echo base_url();?>js/jquery.js"></script>
      <script src="<?php echo base_url();?>js/jquery-ui-1.10.4.min.js"></script>
      <script src="<?php echo base_url();?>js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.9.2.custom.min.js"></script>
      
      <!-- bootstrap -->
      <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
      
      <!-- nice scroll -->
      <script src="<?php echo base_url();?>js/jquery.scrollTo.min.js"></script>
      <script src="<?php echo base_url();?>js/jquery.nicescroll.js" type="text/javascript"></script>
      
      <!-- charts scripts -->
      <script src="<?php echo base_url();?>assets/jquery-knob/js/jquery.knob.js"></script>
      <script src="<?php echo base_url();?>js/jquery.sparkline.js" type="text/javascript"></script>
      <script src="<?php echo base_url();?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
      <script src="<?php echo base_url();?>js/owl.carousel.js" ></script>
      
      <!-- jQuery full calendar -->
      <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script> 
      <!-- Full Google Calendar - Calendar -->
      <script src="<?php echo base_url();?>assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
      <script type="text/javascript" src="<?php echo asset_url(); ?>js/bootbox.min.js"></script>
      
      <!--script for this page only-->
      <script src="<?php echo base_url();?>js/calendar-custom.js"></script>
      <script src="<?php echo base_url();?>js/jquery.rateit.min.js"></script>
      
      <!-- custom select -->
      <script src="<?php echo base_url();?>js/jquery.customSelect.min.js" ></script>
      <script src="<?php echo base_url();?>assets/chart-master/Chart.js"></script>
      
      <!--custome script for all page-->
      <script src="<?php echo base_url();?>js/scripts.js"></script>
      
      <!-- custom script for this page-->
      <script src="<?php echo base_url();?>js/sparkline-chart.js"></script>
      <script src="<?php echo base_url();?>js/easy-pie-chart.js"></script>
      <script src="<?php echo base_url();?>js/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="<?php echo base_url();?>js/jquery-jvectormap-world-mill-en.js"></script>
      <script src="<?php echo base_url();?>js/xcharts.min.js"></script>
      <script src="<?php echo base_url();?>js/jquery.autosize.min.js"></script>
      <script src="<?php echo base_url();?>js/jquery.placeholder.min.js"></script>
      <script src="<?php echo base_url();?>js/CapsLock.src.js"></script>
      <script src="<?php echo base_url();?>js/gdp-data.js"></script>	
      <script src="<?php echo base_url();?>js/morris.min.js"></script>
      <script src="<?php echo base_url();?>js/sparklines.js"></script>	
      <script src="<?php echo base_url();?>js/charts.js"></script>
      <script src="<?php echo base_url();?>js/jquery.slimscroll.min.js"></script>
   
		<script src="<?php echo base_url(); ?>js/form-validation-create_sales -rep-issue.js"></script>
        <script src="<?php echo base_url(); ?>js/sales_rep_issue.js"></script>
		 <script type="text/javascript" src="<?php echo base_url(); ?>js/accounting.js"></script>
          <script type="text/javascript" src="<?php echo base_url(); ?>js/accounting.min.js"></script>
          
          
          <script src="<?php echo base_url(); ?>js/moment-with-locales.js"></script>	
		
 <script>
 
 

var rowcount=1;

add_cretical_items();



function addextraprice(){
	calculateTotal();
}

clearForm();

$('#add_item').keypress(function(e){
	
    if ( e.which == 13 ) return false;
    //or...
    if ( e.which == 13 ) e.preventDefault();
 }); 


function changeQtyByProductID(qty,nxtCount)
{
	calculateTotal();
}


function getNextRefNo(){
	
$.post( "<?php echo base_url();?>sales_rep_issue2/get_next_ref_no").done(function( data ) 
{
var obj = jQuery.parseJSON(data);
$('#sales_rep_issue_next_ref_number').val(obj.sales_rep_issue_next_ref_number);
		 
});	

}

 $("#initioal_order_form").submit(function(event) {
        event.preventDefault();
        $("#invalid-pass-error").addClass("hide");
 

        var rowCount=$('#rowCount').val();
        $.ajax({
            url: "<?php echo base_url(); ?>order/initial_order_save", data: $(this).serialize(), type: "POST", dataType: 'json',
            success: function(e) {
				//window.alert(e.group_id);
                if (!e.status) {
					
					
					 
    				
                    alert("e.message");
                 
                    return false;
                } else {
                    if(e.status=="1"){
                       alert(e.message);
               
					  clearForm();
                        
                    }
                    
                    

                }


            }
        });

    });







function add_items(){
	

        
		
		
		
		var v=1;
		
		if(v==0)
		{
			
			
		
		 
		}
		
		else{
		


		
        $("#add_item").autocomplete(
		{
            source: '<?php echo base_url();?>order/get_product_suggestion?t='+$("#in_type").val(),
            minLength: 1,
            autoFocus: false,
            delay: 5,
            response: function (event, ui) {
				
			
				if (ui.content.length == 1 && ui.content[0].product_id != 0)
				{
					
				}else if(ui.content.length ==0){
					var noResult = { value:"",label:"No matching result found! Product might be not in  selected warehouse." };
            		ui.content.push(noResult);
				}else {
					

				}
			
            },
            select: function (event, data) {
				
				if(data.item.value){
					
					//check is added prodcut
					rowCount=parseInt($('#rowCount').val());
					var tmp='';
					if(rowCount){
	  					tmp=isAddedProduct(data.item.product_id);
					}
	   				if(!tmp){
				addProductToListByID(rowcount,data.item.product_id,data.item.product_name,data.item.product_code,data.item.product_qty,data.item.product_part_no,data.item.product_oem_part_number,data.item.item_cost);
				rowcount=rowcount+1;
				
				
				
				
					}else {
						calculateTotal();
					}
				
				
				$("#add_item").val('');
					 return false;
				}
				$(this).autocomplete('close');
                    $(this).removeClass('ui-autocomplete-loading');
				
            }
        });
		
		}
}
		
		
		
		
		$(window).scroll(function() {
   if($(window).scrollTop() + $(window).height() == $(document).height()) {
      
	   $('#bottom-total').css({
        position: 'static',
		width: '100%'
    });
   }else {
	    $('#bottom-total').css({
        position: 'fixed',
		width: '1082px'
    });
   }
});

//function to initiate bootstrap-datepicker
$(function () {
	
	
	var currentDate = new Date();
	
	
	$('#sales_rep_issue_datetime').datetimepicker({
		defaultDate: new Date()
		
		});
	
	;
	$("#sales_rep_id").select2();
	$("#warehouse_id").select2();
	$("#secondry_sales_rep_id").select2();
	
	
	
});	

$(document).ready(function() {
	
	 $('#in_type').focus();
	 
	 calculateTotal();

$(".noEnterSubmit").on('keyup', function (e) {
   
});



$('#sales_rep_issue').keypress(function(event){
	
});	
	
  $(window).keydown(function(event){
	 $(":focus").each(function() {
    
	focus_id=this.id;
	
	  var rowCount=$('#rowCount').val();
	  var fld='quantity_'+rowCount;
	  if(focus_id==fld){
		if(event.keyCode == 16) {
			  $('#add_item').focus();
		}
	  }
    if(event.keyCode == 18) {
		calculateTotal();
		
	setTimeout(function(){
  
	  $("#create_sales_form").submit()
    //do something special
	

	
  }, 1000);
  
  
	
    }
		  
    if(event.keyCode == 13) {
      event.preventDefault();
     return false;
    }
  });
  
  });
});





window.onload = function () {
    if (! localStorage.justOnce) {
        localStorage.setItem("justOnce", "true");
        window.location.reload();
    }
}


function add_cretical_items()
{ 


$("#tbodys").empty();



$.ajax({
      type: 'POST',
      url: "<?php echo  base_url(); ?>order/get_cretical_items",
      success: function(result) {
        
		
		
				var obj = JSON.parse(result);
				
				//window.alert(result);
				Object.size = function(obj) {
   				 var size = 0, key;
   			 for (key in obj) {
       			 if (obj.hasOwnProperty(key)) size++;
  				  }
  			  return size;
				};
				
				var size = Object.size(obj);
				
				
				
				for(c=0;c<size;c++)
				{
		       		var item_id=obj[c].item_id;
					var item_name=obj[c].item_name;
					var item_code=obj[c].item_code;
					var unit_price=obj[c].unit_price;
					var req_qty=obj[c].req_qty;
					var supplier_id=obj[c].supplier_id;
					
					
					
					addProductToListByID(c+1,item_id,item_name,item_code,unit_price,55,66,supplier_id,req_qty);
				}
		
		
		
		
		
		
		
		
      },
  });








}

	
	
			

  </script>

  </body>
</html>
