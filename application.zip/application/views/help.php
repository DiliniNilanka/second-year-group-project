<html>
<head>
<title>help window</title>
</head>
<body>
<div>
<h2><b>SMART KSR System</b></h2>
<h3><b>Web Based Smart Assistant For Kitchen, Store & Restaurant Inventory Management</b></h3>
<p>This manual documents how to use SMART KSR system.</p>
<h4>Menu:</h4>
<ul>
<li>Assistant Chef (Assistant Restaurant Head)
<ul><li><a name= "issue items" href=help_issue_items.html>issue items</a></li>
<li><a name= "order request" href=help_order_request.html>order requests</a></li>
</ul></li><br><br>
<li>Head Chef (Restaurant Head)
<ul><li><a name= "issue items" href=help_issue_items.html>issue items</a>
<li><a name= "order request" href=help_order_request.html>order requests</a></li>
<li><a name= "view store" href=help_view_store.html>view store</a></li>
</ul></li><br><br>
<li>Assistant Store Manager
<ul><li><a name= "issue items" href=help_issue_items.html>issue items</a></li>
<li><a name="view stock(mini & main)" href=view_stock_main_mini.html>view stock(main & mini)</a></li>
<li><a name="view request report" href=view_request_report.html>view request report</a></li>
<li><a name="generate order" href=generate_order.html>generate order</a></li>
<li><a name="update new stock levels" href=update_new_stock_levels.html>update new stock levels</a></li>
</ul></li><br><br>
<li>Store Manager
  <ul>
  <li><a name= "issue items" href=help_issue_items.html>issue items</a></li>
  <li><a name="view stock(mini & main)" href=view_stock_main_mini.html>view stock(main & mini)</a></li>
  <li><a name="view request report" href=view_request_report.html>view request report</a></li>
  <li><a name="Accept or Reject order" href=accept_or_reject_order.html>Accept or Reject order</a></li>
  <li><a name="generate order" href=generate_order.html>generate order</a></li>
  <li><a name="update new stock levels" href=update_new_stock_levels.html>update new stock levels</a></li>
  </ul>
</li><br><br>
<li>Assistant General Manager
<ul><li><a name="accept or reject orders" href=accept_or_reject_order.html>Accept or Reject order</a></li>
<li><a name="generate purchase order" href=generate_purchase_order.html>generate purchase order</a></li>
</ul>
</li>
</ul>
</div>
</body>
</html>