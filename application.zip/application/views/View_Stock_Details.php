<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Smart KSR system</title>
    
    
		<link rel="stylesheet" href="<?php echo base_url('plugins/DataTables/media/css/DT_bootstrap.css')?>"/>
		<link href="<?php echo base_url('plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css')?>"  rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url('plugins/bootstrap-modal/css/bootstrap-modal.css')?>"  rel="stylesheet" type="text/css"/>
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-fileupload/bootstrap-fileupload.min.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/select2/select2.css')?>">


		
		<link rel="stylesheet" href="<?php echo base_url('plugins/datepicker/css/datepicker.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-daterangepicker/daterangepicker-bs3.css')?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css') ?>" >
		<link rel="stylesheet" href="<?php echo base_url('plugins/jQuery-Tags-Input/jquery.tagsinput.css')?>" >
		
		<link rel="stylesheet" href="<?php echo base_url('plugins/summernote/build/summernote.css')?>" >

		<style type="text/css">
			.table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td, .table-striped thead tr.primary:nth-child(2n+1) th {
			    background-color: #428bca;
			    border-color: #357ebd;
			    border-top: 1px solid #357ebd;
			    color: white;
			    text-align: center;
			}

		</style>
    
    
    
    

    <!-- Bootstrap CSS -->    
    <link href="<?php echo base_url()?>css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="<?php echo base_url()?>css/bootstrap-theme.css"  rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="<?php echo base_url()?>css/elegant-icons-style.css"  rel="stylesheet" />
    <link href="<?php echo base_url()?>css/font-awesome.min.css"  rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="<?php echo base_url()?>assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css"  rel="stylesheet" />
	<link href="<?php echo base_url()?>assets/fullcalendar/fullcalendar/fullcalendar.css"  rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="<?php echo base_url()?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css"  rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url()?>css/owl.carousel.css" type="text/css">
	<link href="<?php echo base_url()?>css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="<?php echo base_url()?>css/fullcalendar.css" >
	<link href="<?php echo base_url()?>css/widgets.css"  rel="stylesheet">
    <link href="<?php echo base_url()?>css/style.css"  rel="stylesheet">
    <link href="<?php echo base_url()?>css/style-responsive.css"  rel="stylesheet" />
	<link href="<?php echo base_url()?>css/xcharts.min.css"  rel=" stylesheet">	
	<link href="<?php echo base_url()?>css/jquery-ui-1.10.4.min.css"  rel="stylesheet">



  </head>

  <body>

     
  <!-- container section start -->
  <section id="container" class="">
     
      
    <section id="container" class="">
     
      <?php $this->load->view('common/header'); ?>
        
    <!--header end-->

      <!--sidebar start-->
      <?php $this->load->view('common/navigation'); ?>
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-home"></i> View Stock Data</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-table"></i>Stock</li>
                        <li><i class="fa fa-th-list"></i>View Stock Data</li>
												  	
					</ol>
				</div>
			</div>
              
            
		
			
           
			
              
				
			

				</div><!--/col-->

            <div class="row">
                <?php /*?><div class="col-sm-6">
                    
                        <div class="nav search-row" id="top_menu">
                            <!--  search form start -->
                            <ul class="nav top-menu">                    
                                <li>
                                    <form class="navbar-form">
                                        <input class="form-control" placeholder="Search" type="text" name="term">
                                    </form>
                                </li>                    
                            </ul>
                            <!--  search form end -->                
                        </div>
                        
                </div>
            
                <div class="col-lg-2">
                    <a class="btn btn-primary" href="" title="Search Inventory">Search</a>
                </div><?php */?>
                <div class="col-lg-2">
                    <a class="btn btn-primary" href="<?php echo base_url('store/add_items');?>" title="Search Inventory">Add Items</a>
                </div>
                
                
            </div>

            


			<div>

                <!--some empty space-->
                <br>
                <br>

            </div>

            <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Store View
                          </header>
                          <table class="table table-bordered table-condensed table-hover table-striped dataTable" id="stock_table">
                              <thead>
                              <tr>
                                  <th>Item Code</th>
                                  <th>Product Title</th>
                                  <th>Brand</th>
                                  <th>Category</th>
                                  <th>Unit</th>
                                  <th>Quantity</th>
                                  <th>Critical Level</th>
                                  <th>Action</th>
                                  
                              </tr>
                              </thead>
                              <tbody>
                                    <?php
                                  /*  if (empty($result2)){
                                      while( $row = mysql_fetch_assoc( $result1 ) ){
                                        echo
                                        "<tr>
                                          <td>{$row['item_id']}</td>
                                          <td>{$row['item_name']}</td>
                                          <td>{$row['brand_name']}</td>
                                          <td>{$row['category_name']}</td>
                                          <td>{$row['unit_name']}</td>
                                          <td>{$row['qty']}</td>
                                          <td>{$row['critical_level']}</td>
                                          <td>{$row['description']}</td>
                                           
                                        </tr>\n";
                                      }
                                    }else{
                                      while( $row = mysql_fetch_assoc( $result2 ) ){
                                        echo
                                        "<tr>
                                          <td>{$row['item_id']}</td>
                                          <td>{$row['item_name']}</td>
                                          <td>{$row['brand_name']}</td>
                                          <td>{$row['category_name']}</td>
                                          <td>{$row['unit_name']}</td>
                                          <td>{$row['qty']}</td>
                                          <td>{$row['critical_level']}</td>
                                          <td>{$row['description']}</td>
                                           
                                        </tr>\n";

                                    }
                                  }
                                    */?>
                              
                              </tbody>
                          </table>
                          <?php //mysql_close($connector); ?>
                      </section>
                  </div>
                   
              
            
				

            

                  
		
		
			
			

          </section>
        <!-- ______________________________________________________Unwanted Space___________________________________________ -->


          <div class="text-right">
          <div class="credits">
                <a href="https://bootstrapmade.com/free-business-bootstrap-themes-website-templates/"></a> <a href="https://bootstrapmade.com/"></a>
            </div>
        </div>

        <!--____________________________________________________END of Unwanted Space________________________________________-->

      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->
    
    <!-- javascripts -->

    <script src="js/jquery.js"></script>
	  <script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <script src="js/fullcalendar.min.js"></script> <!-- Full Google Calendar - Calendar -->
	  <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="js/calendar-custom.js"></script>
	  <script src="js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="js/jquery.customSelect.min.js" ></script>
	  <script src="assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
	  <script src="js/jquery-jvectormap-1.2.2.min.js"></script>
	  <script src="js/jquery-jvectormap-world-mill-en.js"></script>
  	<script src="js/xcharts.min.js"></script>
  	<script src="js/jquery.autosize.min.js"></script>
  	<script src="js/jquery.placeholder.min.js"></script>
  	<script src="js/gdp-data.js"></script>	
  	<script src="js/morris.min.js"></script>
  	<script src="js/sparklines.js"></script>	
  	<script src="js/charts.js"></script>
  	<script src="js/jquery.slimscroll.min.js"></script>
    <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
          <script type="text/javascript" src="js/dataTables.bootstrap.min.js"></script>
    
    <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});
	
	
	
			jQuery(document).ready(function() {
				//TableData.init();
				loadGrid();
			});


			function loadGrid() {

					    $('#stock_table').DataTable({
					        "ajax": "<?php echo base_url('store/get_all_item') ?>",
					        "bDestroy": true,
					        "iDisplayLength": 10,
							 "order": [[ 0, "asc" ]]
					    });

					}

  </script>

  </body>
</html>
