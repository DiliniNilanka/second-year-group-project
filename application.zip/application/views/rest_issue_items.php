<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Smart KSR system</title>

    <!-- Bootstrap CSS -->    
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="<?php echo base_url();?>css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="<?php echo base_url();?>css/elegant-icons-style.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="<?php echo base_url();?>assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="<?php echo base_url();?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url();?>css/owl.carousel.css" type="text/css">
	<link href="<?php echo base_url();?>css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link href="<?php echo base_url();?>css/widgets.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/style-responsive.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>css/xcharts.min.css" rel=" stylesheet">	
	<link href="<?php echo base_url();?>css/jquery-ui-1.10.4.min.css" rel="stylesheet">
   <link rel="stylesheet" href="<?php echo base_url(); ?>css/jquery-ui.css">




   
        <!-- Latest compiled and minified JavaScript -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   
        
        




  </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
     
      <?php $this->load->view('common/header'); ?>
        
    <!--header end-->

      <!--sidebar start-->
      <?php $this->load->view('common/navigation'); ?>
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-home"></i> Home</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
					</ol>
					
				</div>
			</div>
              
            
		
			
           

				</div><!--/col-->





        <!-- <div class="col-md-4 col-md-offset-4" style="margin-top: 200px;">
                
                    <label class="control-lable" style="color: #fff;">Country Name</label>
                    <input style="height:70px" type="text" id="get_item" autocomplete="off" name="get_item" class="form-control" placeholder="Type dude">        
                    <ul class="dropdown-menu txtcountry" style="margin-left:15px;margin-right:0px;" role="menu" aria-labelledby="dropdownMenu"  id="DropdownCountry"></ul>
        </div>
 -->












				

                    
                   
        <div id="show_form">
            
          <div class="col-lg-2">
            
          </div>
          <div class="col-lg-8">
            
        <!-- created a form for getting item id and search for the item -->
              <?php
                echo form_open(base_url('rest_issue_items_cntrl/select_by_id'));
                
                $data = array(
                  'name' => 'get_item',
                  'id' => 'get_item',
                  'placeholder' => 'Please Enter ID',
                  'class' => "form-control"
                  );
                echo form_input($data);
                echo ("<ul class='dropdown-menu txtcountry' style='margin-left:15px;margin-right:0px;' role='menu' aria-labelledby='dropdownMenu'  id='Dropdownitems'></ul>");
                echo "<div class='error_msg'>";
                
                if (isset($id_error_message)) {
                  //echo $id_error_message;
                  echo ("<div class='col-lg-6'></div><div class='col-lg-12'><div class='alert alert-block alert-danger fade in'>
                                  <button data-dismiss='alert' class='close close-sm' type='button'>
                                      <i class='icon-remove'></i>
                                  </button>
                                  <center>Id field is required</center> 
                              </div></div>  ");
                  }

                echo "</div>";
                $data2 = array(
                  'class' => "btn btn-primary"
                );
                echo "<br>";
                echo form_submit('submit', 'Search',$data2);
                echo form_close();


          ?>

         
            

         
        
      </div>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>

          <div class="message">
            <div class="col-lg-8">
              <section class="panel">

                <!-- show the results found on search using a table -->
                <?php
                  if (isset($result_display)) {
                    //echo "<p><u>Result</u></p>";
                  if ($result_display == 'No record found !') {
                    //echo $result_display;
                    echo ("<div class='col-lg-6'></div><div class='col-lg-6'><div class='alert alert-block alert-danger fade in'>
                                  <button data-dismiss='alert' class='close close-sm' type='button'>
                                      <i class='icon-remove'></i>
                                  </button>
                                  <strong><center>No record found !<center></strong> 
                              </div></div>  ");
                  } else {
                    echo "<table class='table'>";
                    echo '<tr><th>Item ID</th><th>Item Name</th><th>current Quantity</th><tr/>';
                    foreach ($result_display as $value) {
                      echo '<tr>' . '<td class="e_id">' . $value->item_code . '</td>' . '<td>' . $value->item_name . '</td>' . '<td class="j_date">' . $value->current_q . '</td>' .'<td class="mob">' . '<tr/>';
                    }

                    echo '</table>';
                    }
                  }
                ?>
              </section>
        </div>

        <!-- <br> -->
        <br>
        <br>
        
        <div class="col-lg-4">

          <?php
          if(isset($result_display)){
            if ($result_display != 'No record found !')
            {
              foreach($result_display as $value) {

                $name = $value->item_name;
                $id = $value->item_code;

              }
              }
              } ;

          ?>


          <!-- create a hidden form for get values from result_display array show only some parts. -->
          <!-- also send those values to a temp table for later use -->
            <form type="" action="<?php echo base_url('rest_issue_items_cntrl/add_item'); ?>" method="post">
              <?php if(!empty($result_display)) {
                        if($result_display != 'No record found !') {
                          echo "<label>Required Quantity</label>";
                        }
                        }   ?>
                <input type="<?php if(!empty($result_display)) {if($result_display == 'No record found !') {echo "hidden";}else{echo "text";}}else{echo "hidden";}  ?>" name = "quantity" >
                <input type="hidden" name="item_name" value = " <?php if(isset($name)){ echo $name;} ?>">
                <input type="hidden" name="item_id" value = " <?php if(isset($name)){ echo $id;} ?>">
               <input class="btn btn-primary btn-sm" title="" type="<?php if(!empty($result_display)) {if($result_display == 'No record found !') {echo "hidden";}else{echo "submit";}}else{echo "hidden";}  ?>">
                
            </form>
            
          
        </div>

          </div>
          </div>

          <div class="col-lg-2">
          </div>
          <div class="col-lg-8">
          <section class="panel">

            <!-- display all the data in temp table(order table) -->
          <?php

                if(!empty($order_tbl)) {
                    
                    echo "<table class='table'>";
                    echo '<tr><th>Item Name</th><th>Quantity</th><tr/>';
                    foreach ($order_tbl as $value) {
                      echo '<tr>' . '<td class="e_id">' . $value->item_name . '</td>' . '<td class="j_date">' . $value->quantity . '</td>' . '<tr/>';
                    }

                    echo '</table>';

                  }

              ?>

              </section>
              </div>


              <div class="col-lg-8"></div>
              <div class="col-lg-2">

                  <!-- issue items by updating mini store and clear temp table -->
                  <form type="" action="<?php echo base_url('rest_issue_items_cntrl/allocate_items');?>" method="post">
                     
                      <input class="btn btn-primary btn-sm" title="" type="<?php if(empty($order_tbl)){echo "hidden";}else{echo "submit";}  ?>" value="confirm" >
                
                  </form>
              </div>

         
              
            
				

            

                  
		
		
			
			

         
      <!--main content end-->
  </section>
  <!-- container section start -->

    <!-- javascripts -->
    <script src="<?php echo base_url();?>js/jquery.js"></script>
	<script src="<?php echo base_url();?>js/jquery-ui-1.10.4.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="<?php echo base_url();?>js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="<?php echo base_url();?>assets/jquery-knob/js/jquery.knob.js"></script>
    <script src="<?php echo base_url();?>js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="<?php echo base_url();?>js/owl.carousel.js" ></script>
    <!-- jQuery full calendar -->
    <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script><!-- Full Google Calendar - Calendar -->
	<script src="<?php echo base_url();?>assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <!--script for this page only-->
    <script src="<?php echo base_url();?>js/calendar-custom.js"></script>
	<script src="<?php echo base_url();?>js/jquery.rateit.min.js"></script>
    <!-- custom select -->
    <script src="<?php echo base_url();?>js/jquery.customSelect.min.js" ></script>
	<script src="<?php echo base_url();?>assets/chart-master/Chart.js"></script>
   
    <!--custome script for all page-->
    <script src="<?php echo base_url();?>js/scripts.js"></script>
    <!-- custom script for this page-->
    <script src="<?php echo base_url();?>js/sparkline-chart.js"></script>
    <script src="<?php echo base_url();?>js/easy-pie-chart.js"></script>
	<script src="<?php echo base_url();?>js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="<?php echo base_url();?>js/jquery-jvectormap-world-mill-en.js"></script>
	<script src="<?php echo base_url();?>js/xcharts.min.js"></script>
	<script src="<?php echo base_url();?>js/jquery.autosize.min.js"></script>
	<script src="<?php echo base_url();?>js/jquery.placeholder.min.js"></script>
	<script src="<?php echo base_url();?>js/gdp-data.js"></script>	
	<script src="<?php echo base_url();?>js/morris.min.js"></script>
	<script src="<?php echo base_url();?>js/sparklines.js"></script>	
	<script src="<?php echo base_url();?>js/charts.js"></script>
	<script src="<?php echo base_url();?>js/jquery.slimscroll.min.js"></script>




<script>
  $(document).ready(function () {
    $("#get_item").keyup(function () {
        $.ajax({
            type: "POST",
            url: "http://localhost/ucsc_new/rest_issue_items_cntrl/get_item_name",
            data: {
                keyword: $("#get_item").val()
            },
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                    $('#Dropdownitems').empty();
                    $('#get_item').attr("data-toggle", "dropdown");
                    $('#Dropdownitems').dropdown('toggle');
                }
                else if (data.length == 0) {
                    $('#get_item').attr("data-toggle", "");
                }
                $.each(data, function (key,value) {
                    if (data.length >= 0)
                        $('#Dropdownitems').append('<li role="displayCountries" ><a role="menuitem dropdownCountryli" class="dropdownlivalue">' + value['item_name'] + '</a></li>');
                });
            }
        });
    });
    $('ul.txtcountry').on('click', 'li a', function () {
        $('#get_item').val($(this).text());
    });
});
</script>








  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
    
    /* ---------- Map ---------- */
  $(function(){
    $('#map').vectorMap({
      map: 'world_mill_en',
      series: {
        regions: [{
          values: gdpData,
          scale: ['#000', '#000'],
          normalizeFunction: 'polynomial'
        }]
      },
    backgroundColor: '#eef3f7',
      onLabelShow: function(e, el, code){
        el.html(el.html()+' (GDP - '+gdpData[code]+')');
      }
    });
  });

  </script>
   

  </body>
</html>
