<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Smart KSR system</title>
    
    
    	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>plugins/select2/select2.css" />
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/DataTables/media/css/DT_bootstrap.css"/>
		<link href="<?php echo base_url()?>plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css"  rel="stylesheet" type="text/css" />
		<link href="<?php echo base_url()?>plugins/bootstrap-modal/css/bootstrap-modal.css"  rel="stylesheet" type="text/css"/>
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/bootstrap-fileupload/bootstrap-fileupload.min.css" >
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/select2/select2.css">


		<link rel="stylesheet" href="<?php echo base_url()?>plugins/select2/select2.css" >
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/datepicker/css/datepicker.css" >
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css" >
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/bootstrap-daterangepicker/daterangepicker-bs3.css" >
		<link rel="stylesheet" href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css" >
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/jQuery-Tags-Input/jquery.tagsinput.css" >
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/bootstrap-fileupload/bootstrap-fileupload.min.css" >
		<link rel="stylesheet" href="<?php echo base_url()?>plugins/summernote/build/summernote.css" >

		<style type="text/css">
			.table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td, .table-striped thead tr.primary:nth-child(2n+1) th {
			    background-color: #428bca;
			    border-color: #357ebd;
			    border-top: 1px solid #357ebd;
			    color: white;
			    text-align: center;
			}

		</style>
    
    
    
    

    <!-- Bootstrap CSS -->    
    <link href="<?php echo base_url()?>css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="<?php echo base_url()?>css/bootstrap-theme.css"  rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="<?php echo base_url()?>css/elegant-icons-style.css"  rel="stylesheet" />
    <link href="<?php echo base_url()?>css/font-awesome.min.css"  rel="stylesheet" />    
    <!-- full calendar css-->
    <link href="<?php echo base_url()?>assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css"  rel="stylesheet" />
	<link href="<?php echo base_url()?>assets/fullcalendar/fullcalendar/fullcalendar.css"  rel="stylesheet" />
    <!-- easy pie chart-->
    <link href="<?php echo base_url()?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css"  rel="stylesheet" type="text/css" media="screen"/>
    <!-- owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url()?>css/owl.carousel.css" type="text/css">
	<link href="<?php echo base_url()?>css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
    <!-- Custom styles -->
	<link rel="stylesheet" href="<?php echo base_url()?>css/fullcalendar.css" >
	<link href="<?php echo base_url()?>css/widgets.css"  rel="stylesheet">
    <link href="<?php echo base_url()?>css/style.css"  rel="stylesheet">
    <link href="<?php echo base_url()?>css/style-responsive.css"  rel="stylesheet" />
	<link href="<?php echo base_url()?>css/xcharts.min.css"  rel=" stylesheet">	
	<link href="<?php echo base_url()?>css/jquery-ui-1.10.4.min.css"  rel="stylesheet">



  </head>

  <body>

     
  <!-- container section start -->
  <section id="container" class="">
     
      
    <section id="container" class="">
     
      <?php $this->load->view('common/header'); ?>
        
    <!--header end-->

      <!--sidebar start-->
      <?php $this->load->view('common/navigation'); ?>
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-home"></i> Add Items</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-table"></i>Stock</li>
                        <li><i class="fa fa-th-list"></i>Add Items</li>
												  	
					</ol>
				</div>
			</div>
              
            
		
			
           
			
              
				
			

				</div><!--/col-->

           <div class="col-md-12">
							<!-- start: DYNAMIC TABLE PANEL -->
							<div class="panel panel-default">
								<div class="panel-heading">
									<i class="fa fa-external-link-square"></i>
									Add Items
								</div>
                                
                                <div class="panel-body">
								    <div id="error"></div>
								
         <form id="add_product_form" name="add_product_form"  class="form-horizontal">                                                                    
										<div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-1">
												Item Name
											*</label>
											<div class="col-sm-9">
												<input type="text" id="item_name" class="form-control" name="item_name" required>
											</div>
										</div>

										
                                       
                                      
									  <div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-3" >
												Category*
											</label>
											<div class="col-sm-9">
												<select required class="form-control search-select" id="category" name="category">
												<option value="">&nbsp;</option>
													<?php foreach ($main_category as $key => $category) {?>
														<option value="<?php echo $category['id']; ?>"><?php echo $category['category_name']; ?></option>										
													<?php } ?>
												</select>
                                        
											</div>
										</div>
 								<div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-3" >
												Sub Category
											</label>
											<div id="subcat_data" class="col-sm-9">
											<select required data-placeholder="Select Category to load Subcategories" id="subcategory" class="form-control search-select" name="subcategory">
											<option selected="selected" value="1">Comman</option>
											</select>
											</div>
										</div>
                                        <div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-2">
											Brand *
											</label>
											<div class="col-sm-9">
												<select required  class="form-control search-select" id="brand" name="brand">
                                                <option selected="selected" value="1">Comman</option>
						                            <?php /*foreach ($unit_type as $key => $unit) {
						                            	if ($unit->unit_code == "Item") {
						                            		echo "<option selected value='$unit->unit_id'>$unit->unit_code</option>";
						                            	}else{
						                            		echo "<option value='$unit->unit_id'>$unit->unit_code</option>";
						                            	}
						                            } */?>  
					                             </select>
											</div>
										</div>
                                        
                                        
                                         <div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-2">
											 Unit *
											</label>
											<div class="col-sm-9">
												<select required  class="form-control search-select" id="unit" name="unit">
						                            <?php foreach ($unit_type as $key => $unit) {
				?>
                	<option value="<?php echo $unit['id']; ?>"><?php echo $unit['unit_name']; ?></option>	
						                            
						                     <?php       } ?>  
					                             </select>
											</div>
										</div>
                                       
                                        <div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-2">
												Unit Price *
											</label>
											<div class="col-sm-9">
												<input required type="text" id="product_price" class="form-control auto" name="product_price" data-a-sign="Rs. " data-d-group="2">
											</div>
										</div>
                                         
                                         
                                                        
                                      
                                      
                                        <div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-2">
												Minimum Quantity
											</label>
											<div class="col-sm-9">
												<input required type="text"  id="alert_quty" name="alert_quty" class="form-control">
											</div>
										</div>
                                         <div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-2">
												Maximum Quantity
											</label>
											<div class="col-sm-9">
												<input required type="text"  id="product_max_qty" name="product_max_qty" class="form-control">
											</div>
										</div>
                                                  
                                        
                                        
                                        
                                        
                                        
                                         <div class="form-group">
											<label class="col-sm-2 control-label" for="form-field-2">
												Store Position
											</label>
											<div class="col-sm-9">
												
                                                <input required type="text" id="store_position" class="form-control" name="store_position">
											</div>
										</div> 
                                       
                                      
                                        <button id="order_btn">order</button>

										<div class="form-group">
                                        <div class="col-sm-12">
												<label class="control-label">
													Product Details *
												</label>
												<textarea class="ckeditor form-control" cols="10" rows="10" name="product_details"></textarea>
                                         </div>
										</div>
                                     <div class="form-group">
                                     <div class="col-sm-12">       
									<button class="btn btn-primary btn-squared" type="submit">
											Add Product
										</button>
                                        </div>
                                        </div>
									</form>
								</div>
							</div>
							</div>
							<!-- end: DYNAMIC TABLE PANEL -->
						</div>
					</div>
                    <!-- end grid -->
			</div>
			<!-- end: PAGE -->
		</div>
		<!-- end: MAIN CONTAINER -->
		<!-- start: FOOTER -->
		
              
            
				

            

                  
		
		
			
			

          </section>
        <!-- ______________________________________________________Unwanted Space___________________________________________ -->


          <div class="text-right">
          <div class="credits">
                <a href="https://bootstrapmade.com/free-business-bootstrap-themes-website-templates/"></a> <a href="https://bootstrapmade.com/"></a>
            </div>
        </div>

        <!--____________________________________________________END of Unwanted Space________________________________________-->

      </section>
      <!--main content end-->
  </section>
  <!-- container section start -->
    
    <!-- javascripts -->

    <script src="<?php echo base_url('js/jquery.js') ?>"></script>
	  <script src="<?php echo base_url('js/jquery-ui-1.10.4.min.js') ?>"></script>
    <script src="<?php echo base_url('js/jquery-1.8.3.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('js/jquery-ui-1.9.2.custom.min.js') ?>"></script>
    <!-- bootstrap -->
    <script src="<?php echo base_url('js/bootstrap.min.js') ?>"></script>
    <!-- nice scroll -->
    <script src="<?php echo base_url('js/jquery.scrollTo.min.js') ?>"></script>
    <script src="<?php echo base_url('js/jquery.nicescroll.js') ?>" type="text/javascript"></script>
    <!-- charts scripts -->
    <script src="<?php echo base_url('assets/jquery-knob/js/jquery.knob.js') ?>"></script>
    <script src="<?php echo base_url('js/jquery.sparkline.js') ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js') ?>"></script>
    <script src="<?php echo base_url('js/owl.carousel.js') ?>" ></script>
    <!-- jQuery full calendar -->
    <script src="<?php echo base_url('js/fullcalendar.min.js') ?>"></script> <!-- Full Google Calendar - Calendar -->
	  <script src="<?php echo base_url('assets/fullcalendar/fullcalendar/fullcalendar.js') ?>"></script>
    <!--script for this page only-->
    <script src="<?php echo base_url('js/calendar-custom.js') ?>"></script>
	  <script src="<?php echo base_url('js/jquery.rateit.min.js') ?>"></script>
    <!-- custom select -->
    <script src="<?php echo base_url('js/jquery.customSelect.min.js') ?>" ></script>
	  <script src="<?php echo base_url('assets/chart-master/Chart.js') ?>"></script>
   
    <!--custome script for all page-->
    <script src="<?php echo base_url('js/scripts.js') ?>"></script>
    <!-- custom script for this page-->
    <script src="<?php echo base_url('js/sparkline-chart.js') ?>"></script>
    <script src="<?php echo base_url('js/easy-pie-chart.js') ?>"></script>
	  <script src="<?php echo base_url('js/jquery-jvectormap-1.2.2.min.js') ?>"></script>
	  <script src="<?php echo base_url('js/jquery-jvectormap-world-mill-en.js') ?>"></script>
  	<script src="<?php echo base_url('js/xcharts.min.js') ?>"></script>
  	<script src="<?php echo base_url('js/jquery.autosize.min.js') ?>"></script>
  	<script src="<?php echo base_url('js/jquery.placeholder.min.js') ?>"></script>
  	<script src="<?php echo base_url('js/gdp-data.js') ?>"></script>	
  	<script src="<?php echo base_url('js/morris.min.js') ?>"></script>
  	<script src="<?php echo base_url('js/sparklines.js') ?>"></script>	
  	<script src="<?php echo base_url('js/charts.js') ?>"></script>
  	<script src="<?php echo base_url('js/jquery.slimscroll.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('js/jquery.dataTables.min.js') ?>"></script>
          <script type="text/javascript" src="<?php echo base_url('js/dataTables.bootstrap.min.js') ?>"></script>
           <script type="text/javascript" src="<?php echo base_url('site_theme/js/bootbox.min.js'); ?>"></script>
  
    
    <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});
	
	 $("#add_product_form").submit(function(event) {
        event.preventDefault();
        $("#invalid-pass-error").addClass("hide");
  
        $.ajax({
            url: "<?php echo base_url(); ?>store/save_item", data: $(this).serialize(), type: "POST", dataType: 'json',
            success: function(e) {
				//window.alert(e.group_id);
                if (!e.status) {
				
                    return false;
                } else {
                    if(e.status=="1"){
                       
                       
                          window.location.href="<?php echo base_url('store'); ?>";
                      
                        
                    }
					else
					{
					 bootbox.alert(e.message);	
					}
                    
                    

                }


            }
        });

    });
	
			
  </script>

  </body>
</html>
