<?php
   // include('session.php');



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

$conn = mysqli_connect($servername,$username,$password,$dbname)
or die('Error connecting to MySQL server.');
?>
