<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class GRN_Model extends CI_Model {

    function __construct() {
        parent::__construct();
		header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
die();
}



       
    }
	
	
	function update_po_master($po_id)
	{
		
		$data = array(
			'approval_status' => 1
		);
		
		
		$this->db->where('id',$po_id);
		$this->db->update('purches_order_master', $data);
		
		
		
	}
	
	
	
	
	
	
	
	function get_product_suggestion($term)
	{
		
		$this->db->select('items'.'.*');
		$this->db->order_by("item_name", "asc");
		
		$this->db->where("item_name LIKE '%$term%' OR item_code LIKE '%$term%'");
		 $this->db->limit(10, 0);
		$query = $this->db->get('items');
		return $query->result_array();
	
	

		
		
	}
	
	
	function check_available_qty($product_id)
	{
	  $this->db->select_sum('store_item.qty');	
	  $this->db->where("store_item.item_id",$product_id);
	  $query = $this->db->get('store_item');
	  return $query->row_array();
	}
	
	
	
	
	 function get_all_store_item()
	
	{
		$this->db->select("items.*");
		$this->db->select("brand.brand_name");
		$this->db->select("category.category_name");
		$this->db->select("unit.unit_name");
		 $this->db->select_sum('store_item.qty');
		$this->db->from("items");
		$this->db->join('store_item','items.id=store_item.item_id','left');
		$this->db->join('brand','items.brand_id=brand.id','left');
		$this->db->join('category','items.item_catogory=category.id','left');
		$this->db->join('unit','items.unit_id=unit.id','left');
		
		$this->db->group_by('items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
		
	}
	
	function save_initial_order_master($data)
	{
	
		$result=$this->db->insert("initial_order",$data);
        $lastid=$this->db->insert_id();
        return $lastid;
	
	}
	
	function save_grn_master($data)
	{
	
		$result=$this->db->insert("grn_master",$data);
        $lastid=$this->db->insert_id();
        return $lastid;
	
	}
	
	function save_initial_order_items($data_item)
	{
			$this->db->insert('initial_order_items',$data_item);
	}	
	
	function save_grn_items($data_item)
	{
			$this->db->insert('grn_items',$data_item);
	}	
	
	

	function get_next_ref_no_grn()
	{
		 $this->db->select_max('id');
	  return $this->db->get('grn_master');
		
	}
	
	function get_all_initial_orders()
	{
		$this->db->select("initial_order.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->from("initial_order");
		$this->db->join('warehouse','initial_order.warehouse_id=warehouse.id','left');
		$this->db->join('user','initial_order.entered_person_id=user.id','left');
		$this->db->where('initial_order.status',0);
		$this->db->group_by('initial_order.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	}
	
	
	
	
	function get_all_grn()
	{
		$this->db->select("grn_master.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->from("grn_master");
		$this->db->join('warehouse','grn_master.warehouse_id=warehouse.id','left');
		$this->db->join('user','grn_master.person_id=user.id','left');
		$this->db->where('grn_master.is_deleted',0);
		$this->db->group_by('grn_master.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	}
	
	
	function get_po_master_details($id)
	{
		
		$this->db->select("purches_order_master.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->from("purches_order_master");
		$this->db->join('warehouse','purches_order_master.warehouse_id=warehouse.id','left');
		$this->db->join('user','purches_order_master.person_id=user.id','left');
		$this->db->where('purches_order_master.is_deleted',0);
		$this->db->where('purches_order_master.id',$id);
		$this->db->group_by('purches_order_master.id','asc');
		$query=$this->db->get();
		return $query->row_array();
		
	
	}
	
	function get_po_items_details($id){
		
		$this->db->select("purches_order_items.*");
		
		$this->db->select("items.item_name, items.item_code");
		$this->db->from("purches_order_items");
		
		$this->db->join('items','purches_order_items.item_id=items.id','left');
	
		$this->db->where('purches_order_items.po_id',$id);
		$this->db->group_by('purches_order_items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	
	}
	
	
	
	
	
	
	function update_grn_master_if_finish($grn_id)
	{
		
		$data = array(
			'status' => 1
		);
		
		
		$this->db->where('id',$grn_id);
		$this->db->update('grn_master', $data);
		
		
		
	}
	
	
	
	
	
	
	function check_older_grn_stock($id)
	{
		
		$this->db->select_sum("qty");
		$this->db->from("store_item");
		$this->db->where('store_item.grn_id',$id);
		$query=$this->db->get();
		return $query->row_array();
	}
	
	
	
	function save_to_store_items($data)
	{
	
	 $result =$this->db->insert('store_item',$data);	
		return $result;
	}
	
	
	
	

	function get_all_grn_items($id)
	{
		
		
		$this->db->select("grn_items.*");
		$this->db->select("items.item_name , items.item_code ");
	
		$this->db->from('grn_items');
		$this->db->join('items','grn_items.item_id=items.id','left');
		
		$this->db->where('grn_items.grn_id',$id);
		$this->db->group_by('grn_items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
		
	}
	
	
	
	
	
	
	function get_all_po_items($id)
	{
		$this->db->select("purches_order_items.*");
		$this->db->select("items.item_name , items.item_code , items.unit_price");
		$this->db->from('purches_order_items');
		$this->db->join('items','purches_order_items.item_id=items.id','left');
		$this->db->where('purches_order_items.po_id',$id);
		$this->db->group_by('purches_order_items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
		
	}

}

?>