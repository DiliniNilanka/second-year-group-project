<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
	
class Wastagem extends CI_Model{
	
	function __construct() {
        parent::__construct();
		header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
die();
}



       
    }
	
	
	public function upade_stock($id,$data)
	{
		$this->db->where('id',$id);
		return $this->db->update('store_item', $data);
		
	}
	
	
	
	
	
	
	public function get_expire_items($cur_date){
		$add_days = 7;
		$date = date('Y-m-d',strtotime($cur_date.' +'.$add_days.' days'));
		$this->db->select('store_item.id,store_item.item_id,store_item.qty,store_item.purches_date,store_item.exp_date,store_item.unit_price');
		$this->db->select('items.item_name ,items.item_code');
		$this->db->from('store_item');
		$this->db->join('items','store_item.item_id=items.id','left');
		$this->db->where("exp_date < '$date'");
		$this->db->where("wastage",0);
		$this->db->order_by('exp_date');
		$query=$this->db->get();
		return $query->result_array();
	}
}
?>