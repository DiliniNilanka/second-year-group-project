<?php

if (!defined('BASEPATH'))exit('No direct script access allowed');

class Rest_Issue_Items_Model extends CI_Model {

	
	public function show_data_by_id($id) {
	$condition = "item_name =" . "'" . $id . "'";
	$this->db->select('*');
	$this->db->from('restaurant_mini_store');
	$this->db->where($condition);
	$this->db->limit(1);
	$query = $this->db->get();

	if ($query->num_rows() == 1) {
		return $query->result();
	} else {
		return false;
	}
	}


	//this function insert data to the temp_rest_issue
	public function insert_selected_items($dataset) {

			$this->db->insert('temp_rest_issue',$dataset);

	}


	public function get_selected_items() {

		$this->db->select("item_id,item_name,quantity");
		$this->db->from('temp_rest_issue');
		$query = $this->db->get();
		return $query->result();

	}

	public function allocate_and_update($W,$X) {
		//print_r($data);
		// $array = json_decode(json_encode($data), true);
		// print_r($array);
		// foreach ($array as $v) {

		// 	$W = $v['item_id'];
		// 	$X = $v['quantity'];
		// 	echo $X;
		 	//echo $W;

		// 	echo"--------------------";
		// 	var_dump($W);
			// $this->db->select("item_id,current_q");
			// $this->db->from('restaurant_mini_store');
			// $this->db->where('item_id' , $W );
			// $query = $this->db->get();
			// $miniS = $query->result();

			//print_r($query->result());
			// $newarray = array(

			// 	'current_q' => ('current_q'- $value->quantity )

			// );
			//print_r($newarray);
			$this->db->set('current_q', 'current_q-'.$X,false);
			$this->db->where('item_code',trim($W));
			$this->db->update('restaurant_mini_store');
		

		

	}

	public function add_to_log_table($dataset) {

		$this->db->insert('rest_issue_log',$dataset);

	}



	public function get_item_by_name($keyword) {   
		$this->db->select('item_name');     
        $this->db->order_by('id', 'DESC');
        $this->db->like("item_name", $keyword);
        $this->db->limit(10, 0);
        return $this->db->get('restaurant_mini_store')->result_array();
    }



	
}