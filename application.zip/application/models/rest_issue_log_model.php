<?php

if (!defined('BASEPATH'))exit('No direct script access allowed');

class Rest_Issue_Log_Model extends CI_Model {


	public function select_log_data() {

		$this->db->select('*');
		$this->db->from('rest_issue_log');
		$this->db->order_by('id','desc');
		$this->db->limit(10);
		$query = $this->db->get();

		if ($query->num_rows() > 0) {
			return $query->result();
		}

	}

	public function get_data($id) {

		$condition = "day =" . "'" . $id . "'";
		$this->db->select('*');
		$this->db->from('rest_issue_log');
		$this->db->where($condition);
		$this->db->order_by('id','desc');
		$this->db->limit(15);
		$query = $this->db->get();

		if ($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	
	}




	public function get_date($keyword) {   
		$this->db->select('day');     
        $this->db->order_by('id', 'DESC');
        $this->db->like('day', $keyword);
        $this->db->limit(10);
        return $this->db->get('rest_issue_log')->result_array();
    }




}