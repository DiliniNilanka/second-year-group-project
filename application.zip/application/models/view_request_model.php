<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class view_request_model extends CI_Model {

    function __construct() {
        parent::__construct();
		header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
die();
}



       
    }


   function get_all_initial_orders_items_kit($id)
	{
		$this->db->select("kitchen_critical_order_items.*");
		$this->db->select("mini_store_kitchen.item_name , item_code , unit_price");
		$this->db->from('kitchen_critical_order_items');
		$this->db->join('mini_store_kitchen','kitchen_critical_order_items.item_id=mini_store_kitchen.id','left');
		$this->db->where('kitchen_critical_order_items.initial_order_id',$id);
		$this->db->group_by('kitchen_critical_order_items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
		
	} 





function get_all_initial_orders_kit()
	{
		$this->db->select("kitchen_critical_order.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->from("kitchen_critical_order");
		$this->db->join('warehouse','kitchen_critical_order.warehouse_id=warehouse.id','left');
		$this->db->join('user','kitchen_critical_order.entered_person_id=user.id','left');
		$this->db->where('kitchen_critical_order.status',0);
		$this->db->group_by('kitchen_critical_order.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	}

function get_all_initial_orders_res()
	{
		$this->db->select("restaurant_critical_order.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->from("restaurant_critical_order");
		$this->db->join('warehouse','restaurant_critical_order.warehouse_id=warehouse.id','left');
		$this->db->join('user','restaurant_critical_order.entered_person_id=user.id','left');
		$this->db->where('restaurant_critical_order.status',0);
		$this->db->group_by('restaurant_critical_order.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	}

}
?>