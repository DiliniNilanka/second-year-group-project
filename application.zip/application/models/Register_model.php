<?php
/**
 * Created by PhpStorm.
 * User: Ramesh
 * Date: 9/17/2017
 * Time: 10:04 AM
 */

class Register_model extends CI_Model{

    public function insert($userData) {

       
      $this->db->insert('user_details',$userData);
     

    }
}