<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Order_Model extends CI_Model {

    function __construct() {
        parent::__construct();
		header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
die();
}



       
    }
	
	
	function update_initial_order_master($initial_order_id)
	{
		
		$data = array(
			'status' => 1
		);
		
		
		$this->db->where('id',$initial_order_id);
		$this->db->update('initial_order', $data);
		
		
		
	}
	
	
	
	
	
	
	
	function get_product_suggestion($term)
	{
		
		$this->db->select('items'.'.*');
		$this->db->order_by("item_name", "asc");
		
		$this->db->where("item_name LIKE '%$term%' OR item_code LIKE '%$term%'");
		 $this->db->limit(10, 0);
		$query = $this->db->get('items');
		return $query->result_array();
	
	

		
		
	}
	
	
	function check_available_qty($product_id)
	{
	  $this->db->select_sum('store_item.qty');	
	  $this->db->where("store_item.item_id",$product_id);
	  $query = $this->db->get('store_item');
	  return $query->row_array();
	}
	
	
	
	
	 function get_all_store_item()
	
	{
		$this->db->select("items.*");
		$this->db->select("brand.brand_name");
		$this->db->select("category.category_name");
		$this->db->select("unit.unit_name");
		 $this->db->select_sum('store_item.qty');
		$this->db->from("items");
		$this->db->join('store_item','items.id=store_item.item_id','left');
		$this->db->join('brand','items.brand_id=brand.id','left');
		$this->db->join('category','items.item_catogory=category.id','left');
		$this->db->join('unit','items.unit_id=unit.id','left');
		
		$this->db->group_by('items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
		
	}
	
	function save_initial_order_master($data)
	{
	
		$result=$this->db->insert("initial_order",$data);
        $lastid=$this->db->insert_id();
        return $lastid;
	
	}
	
	function save_po_order_master($data)
	{
	
		$result=$this->db->insert("purches_order_master",$data);
        $lastid=$this->db->insert_id();
        return $lastid;
	
	}
	
	function save_initial_order_items($data_item)
	{
			$this->db->insert('initial_order_items',$data_item);
	}	
	
	function save_po_order_items($data_item)
	{
			$this->db->insert('purches_order_items',$data_item);
	}	
	
	

	
	function get_next_ref_no_add_item()
	{
		 $this->db->select_max('id');
	  return $this->db->get('items');
		
	}
	
	function get_next_ref_no_initial_order()
	{
		 $this->db->select_max('id');
	  return $this->db->get('initial_order');
		
	}
	
	function get_next_ref_no_po_order()
	{
		 $this->db->select_max('id');
	  return $this->db->get('purches_order_master');
		
	}
	
	function get_all_initial_orders()
	{
		$this->db->select("initial_order.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->from("initial_order");
		$this->db->join('warehouse','initial_order.warehouse_id=warehouse.id','left');
		$this->db->join('user','initial_order.entered_person_id=user.id','left');
		$this->db->where('initial_order.status',0);
		$this->db->group_by('initial_order.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	}
	
	
	function get_all_po()
	{
		$this->db->select("purches_order_master.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->from("purches_order_master");
		$this->db->join('warehouse','purches_order_master.warehouse_id=warehouse.id','left');
		$this->db->join('user','purches_order_master.person_id=user.id','left');
		$this->db->where('purches_order_master.is_deleted',0);
		$this->db->group_by('purches_order_master.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	}
	
	
	function get_po_master_details($id)
	{
		
		$this->db->select("purches_order_master.*");
		$this->db->select("warehouse.warehouse_name");
		$this->db->select("user.username");
		$this->db->select("suppier.supplier_name ,suppier.suplier_address ");
		$this->db->from("purches_order_master");
		$this->db->join('warehouse','purches_order_master.warehouse_id=warehouse.id','left');
		$this->db->join('user','purches_order_master.person_id=user.id','left');
		$this->db->join('suppier','purches_order_master.suppier_id=suppier.id','left');
		
		$this->db->where('purches_order_master.is_deleted',0);
		$this->db->where('purches_order_master.id',$id);
		$this->db->group_by('purches_order_master.id','asc');
		$query=$this->db->get();
		return $query->row_array();
		
	
	}
	
	function get_po_items_details($id){
		
		$this->db->select("purches_order_items.*");
		
		$this->db->select("items.item_name, items.item_code");
		$this->db->from("purches_order_items");
		
		$this->db->join('items','purches_order_items.item_id=items.id','left');
	
		$this->db->where('purches_order_items.po_id',$id);
		$this->db->group_by('purches_order_items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
		
		
		
		
		
	}
	
	
	
	function get_relevent_suplier($order_id)
	{
		$this->db->select("suppier.id , suppier.supplier_name");
		$this->db->from('initial_order_items');
		$this->db->join('suppier','initial_order_items.supplier_id=suppier.id','left');
		$this->db->where('initial_order_items.initial_order_id',$order_id);
		$this->db->where('suppier.status',1);
		$this->db->where('initial_order_items.status',0);
		$this->db->group_by('initial_order_items.supplier_id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
	}
	
	
	function is_all_saved($initial_order_id)
	{
		$this->db->from('initial_order_items');
		$this->db->where('initial_order_items.initial_order_id',$initial_order_id);
		$this->db->where('initial_order_items.status',0);
		$query = $this->db->get();
		$rowcount = $query->num_rows();
		return $rowcount ;
		
	}
	
	
	
	function update_initial_order_relevent_supplier ($initial_order_id,$supplier_id)
	{
		
		$data = array(
			'status' => 1
		);
		
		
		$this->db->where('initial_order_id',$initial_order_id);
		$this->db->where('supplier_id',$supplier_id);
		$this->db->update('initial_order_items', $data);
		
		
		
	}
	
	
	
	
	
	
	function get_all_initial_orders_items($id,$sup_id)
	{
		$this->db->select("initial_order_items.*");
		$this->db->select("items.item_name , item_code , unit_price");
		$this->db->from('initial_order_items');
		$this->db->join('items','initial_order_items.item_id=items.id','left');
		$this->db->where('initial_order_items.status',0);
		$this->db->where('initial_order_items.initial_order_id',$id);
		$this->db->where('initial_order_items.supplier_id',$sup_id);
		$this->db->group_by('initial_order_items.id','asc');
		$query=$this->db->get();
		return $query->result_array();
		
		
		
	}

}

?>