<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class restaurant_mini_store_model extends CI_Model {

    function __construct() {
        parent::__construct();
		header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
$method = $_SERVER['REQUEST_METHOD'];
		if($method == "OPTIONS") {
		die();
		}

	}
	
	
	function get_all_store_item(){

		$this->db->select("restaurant_mini_store.*");
		$query=$this->db->get("restaurant_mini_store");
		return $query->result_array();

		/*$query = $this->db->get('restaurant_mini_store');
        return $query->result();*/
		
	}



function get_product_suggestion($term)
	{
		
		$this->db->select('restaurant_mini_store'.'.*');
		$this->db->order_by("item_name", "asc");
		
		$this->db->where("item_name LIKE '%$term%' OR item_code LIKE '%$term%'");
		 $this->db->limit(10, 0);
		$query = $this->db->get('restaurant_mini_store');
		return $query->result_array();
		
	}

function check_available_qty($product_id)
	{
	  $this->db->select_sum('store_item.qty');	
	  $this->db->where("store_item.item_id",$product_id);
	  $query = $this->db->get('store_item');
	  return $query->row_array();
	}


function get_next_ref_no_initial_order()
	{
		 $this->db->select_max('id');
	  return $this->db->get('restaurant_critical_order');
		
	}	

	function save_initial_order_master($data)
	{
	
		$result=$this->db->insert("restaurant_critical_order",$data);
        $lastid=$this->db->insert_id();
        return $lastid;
	
	}

	function save_initial_order_items($data_item)
	{
			$this->db->insert('restaurant_critical_order_items',$data_item);
	}


		


}
?>