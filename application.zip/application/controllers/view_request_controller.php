<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class view_request_controller extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->model('Stock_Model');
		$this->load->library('form_validation');
		$this->load->model('Catogory_Model');
		$this->load->model('Unit_Model');
		$this->load->model('view_request_model');
		
		
		if($this->session->userdata('ss_status'))
		 		{
			
			
		}
		else
		{
			header('Refresh: 0;url='.base_url('user_authentication'));
			
		}
		
	}


	function generate_purches_order_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 || $this->session->userdata('ss_user_level') == 1) 
					 {
			
			
						$data['id']= $this->input->get('id');
						$this->load->view('view_request_items',$data);
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }			
		
		
		
		
	}


	function generate_purches_order_kit()
	
	{
	
		$id= $this->input->get('id');							 
		$list=$this->view_request_model->get_all_initial_orders_items_kit($id);
		
		$json=array();
	
		
		foreach ($list as $row)
		
		{
			
			
	

			 $json_itm=array(
			 		'item_id'=> $row['item_id'],
					'item_name'=> $row['item_name'],
					'item_code'=> $row['item_code'],
					'req_qty'=> $row['required_qry'],
					'unit_price'=>$row['unit_price'] ,
					            
                    );
		
		array_push($json,$json_itm);
						
				
		}
		
		echo json_encode($json);	
	
	
	
	}


	function initial_order_list_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 || $this->session->userdata('ss_user_level') == 1) 
					 {
   						
						$this->load->view('view_req_new');
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
  }





	/*public function view_request_load(){ 
    
    
    if($this->session->userdata('ss_status')){
          
          
           if (in_array('1', $this->session->userdata('ss_pages'), true)){
              
            $this->load->view('view_req_new');
           
           } 
           else{
            header('Refresh: 0;url='.base_url('user_authentication/logout')); 
           }          
          
          
    }
    
  }*/



public function list_order_kit()
	{
		
		$list=$this->view_request_model->get_all_initial_orders_kit();
		//print_r($list);
		$data=array();
		$temp='';
		
		foreach ($list as $row)
		
		{
			$nested=array();
			
	

			$nested[]=$row['id'];
			$nested[]=$row['order_ref_number'];
			$nested[]=$row['entered_date'];
			$nested[]=$row['warehouse_name'];
			$nested[]=$row['username'];
		    
			$status="";
			if($row['status']==0)
			{
				$status="Pending";
			}
			else{
			if($row['status']==1)
			{
				$status="Approved";
				
			}
			else
			{
				$status="Rejected";
			}
			
			
			}
			
			$nested[]=$status;
			
			$actdes='';
	        $actdes =$actdes. '<div class="btn-group text-left"><a href="'.base_url('view_request_controller/generate_purches_order_view').'?id='.$row['id'].'"><button  class="btn btn-default btn-xs btn-primary" type="button">View Request</button></a></div>';
						
                       
						
						/*$actdes = $actdes.'	
                            <li><a onclick=" print_barcode('.$temp.'); return false;" href="#"><i class="fa fa-print"></i> Reject order</a></li>
                            
                            </ul></div>';*/
							
					$nested[] =$actdes;	
	       
							
							
				
			$data[]=$nested;
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
		
		
		
		
		
		
		
	}

public function list_order_res()
	{
		
		$list=$this->view_request_model->get_all_initial_orders_res();
		//print_r($list);
		$data=array();
		$temp='';
		
		foreach ($list as $row)
		
		{
			$nested=array();
			
	

			$nested[]=$row['id'];
			$nested[]=$row['order_ref_number'];
			$nested[]=$row['entered_date'];
			$nested[]=$row['warehouse_name'];
			$nested[]=$row['username'];
		    
			$status="";
			if($row['status']==0)
			{
				$status="Pending";
			}
			else{
			if($row['status']==1)
			{
				$status="Approved";
				
			}
			else
			{
				$status="Rejected";
			}
			
			
			}
			
			$nested[]=$status;
			
			$actdes='';
	        $actdes =$actdes. '<div class="btn-group text-left"><a href="'.base_url('order/generate_purches_order_view').'?id='.$row['id'].'"><button  class="btn btn-default btn-xs btn-primary" type="button">View Request</button></a></div>';
						
                       
						
						/*$actdes = $actdes.'	
                            <li><a onclick=" print_barcode('.$temp.'); return false;" href="#"><i class="fa fa-print"></i> Reject order</a></li>
                            
                            </ul></div>';*/
							
					$nested[] =$actdes;	
	       
							
							
				
			$data[]=$nested;
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
		
		
		
		
		
		
		
	}	

}
?>