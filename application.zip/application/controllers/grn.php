<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GRN extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->model('Stock_Model');
		$this->load->library('form_validation');
		$this->load->model('Catogory_Model');
		$this->load->model('Unit_Model');
		$this->load->model('GRN_Model');
		
		
		if($this->session->userdata('ss_status'))
		 		{
			
			
		}
		else
		{
			header('Refresh: 0;url='.base_url('user_authentication'));
			
		}
		 
		 
		 
	 
		
	}
	
	
	
	
	
	
	
	

	
	
	
	function po_deatils_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 ||$this->session->userdata('ss_user_level') == 1)  
					 {
						 
						 $id= $this->input->get('id');	
						 
						 $data['po_master_details']=$this->Order_Model->get_po_master_details($id);
						 
						  $data['po_items_details']=$this->Order_Model->get_po_items_details($id);
						 
						
   						
						$this->load->view('view_perches_order',$data);
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
  }
	
	
	function grn_list_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 ||$this->session->userdata('ss_user_level') == 1)  
					 {
   						
						$this->load->view('grn_list_view');
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
  }
  
 
  
  
  	public function list_grn()
	{
		
		$list=$this->GRN_Model->get_all_grn();
		//print_r($list);
		$data=array();
		$temp='';
		
		foreach ($list as $row)
		
		{
			$nested=array();
			
	

			$nested[]=$row['id'];
			$nested[]=$row['grn_referance_no'];
			$nested[]=$row['grn_date_time'];
			$nested[]=$row['warehouse_name'];
			$nested[]=$row['username'];
		    
			$status="";
			if($row['status']==0)
			{
				$status="Pending";
			}
			else{
			if($row['status']==1)
			{
				$status="proceed";
				
			}
			else
			{
				$status="Rejected";
			}
			
			
			}
			
			$nested[]=$status;
			
			$actdes='';
	        $actdes =$actdes. '<div class="btn-group text-left">
                            <button data-toggle="dropdown" class="btn btn-default btn-xs btn-primary dropdown-toggle" type="button">Actions <span class="caret"></span></button>
                            <ul role="menu" class="dropdown-menu pull-right">
                           
							';
							
							if($row['status']==0)
			{
				 $actdes = $actdes.' <li><a href="'.base_url('grn/update_stock').'?id='.$row['id'].'"><i class="fa fa-file-text-o"></i> update Stock </a></li>
							';
			}
			else
			{
				$actdes = $actdes.' <li><a href=""><i class="fa fa-file-text-o"></i> NO action needed</a></li>
							';
				
			}
						
                       
	
				$actdes = $actdes.'	</ul></div>';
				
		
							
					$nested[] =$actdes;	
	       
							
							
				
			$data[]=$nested;
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
		
		
		
		
		
		
		
	}
	
	
	function update_stock()
	{
		 if ($this->session->userdata('ss_user_level') == 2 ||$this->session->userdata('ss_user_level') == 1) 
					 {
   						$data['id']= $this->input->get('id');
						$this->load->view('update_stock_level',$data);
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }		
		
		
		
	}
	
	
	
	function update_grn_list()
	{
		$id= $this->input->get('id');
		$list=$this->GRN_Model->get_all_grn_items($id);
		
		$data=array();
		
		$grn_item_count=0;
		foreach ($list as $row)
		
		{
			$nested=array();
			
			
			
			$temp_qty=$this->GRN_Model->check_older_grn_stock($row['id']);
			
			$older_qty=$temp_qty['qty'];
			
			if($older_qty)
			{
				
			}
			else
			{
			$older_qty=0;	
				
			}
			
			
			
			if($row['received_qty']>$older_qty)
			{
				$grn_item_count=$grn_item_count+1;
				$current_qty=$row['received_qty']-$older_qty;

			$nested[]=$row['id'];
			$nested[]=$row['item_name']." / ".$row['item_code']."<input type='hidden' align='center' name='item_id' id= p_pid_". $row['id']." value ='". $row['item_id']."'  class='form-control  text-right' required> <input type='hidden' align='center' name='unit_price' id=p_unip_".$row['id']." value ='". $row['unit_price']."'  class='form-control  text-right' required>";
			
			
			
		    
			$nested[]="<input type='text' align='center' name='expdate' id= p_". $row['id']." value =''  class='form-control datetime text-right' onclick='set_date(".$row['id'].")' required>";
			
			$nested[]="<input type='text' align='center' name='recived_qty' id= pqty_". $row['id']." value ='".$current_qty."'  class='form-control  text-right' required'>";
		
		
		
		$nested[]="
		
		<div class = 'btn-group' onClick = update_stock(".$row['id'] .")> <a title = '' class = 'btn btn-primary btn-xs' data-original-title = 'Add' > <i class = 'fa fa-money' > </i> <span class = 'hidden-sm hidden-xs' > ADD </span></a>
</div> 
		
	
	
						";
	
				
		
							
			
	       
							
							
				
			$data[]=$nested;
			}
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
		
		if($grn_item_count==0)
		{
			
			$result=$this->GRN_Model->update_grn_master_if_finish($row['grn_id']);
			
		}
		
		
	}
	
	
	
		
		

	
	
	
	function generate_grn_order()
	
	{
	
		$id= $this->input->get('id');							 
		$list=$this->GRN_Model->get_all_po_items($id);
		
		$json=array();
	
		
		foreach ($list as $row)
		
		{
			
			
	

			 $json_itm=array(
			 		'item_id'=> $row['item_id'],
					'item_name'=> $row['item_name'],
					'item_code'=> $row['item_code'],
					'req_qty'=> $row['requsted_qty'],
					'unit_price'=>$row['unit_price'] ,
					            
                    );
		
		array_push($json,$json_itm);
						
				
		}
		
		echo json_encode($json);	
	
	
	
	}
	
	
	
	
	
	function grn_purches_order()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 ||$this->session->userdata('ss_user_level') == 1) 
					 {
			
			
						$data['id']= $this->input->get('id');
						$this->load->view('create_grn',$data);
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }			
		
		
		
		
	}
	
	
	function update_qty_to_store_items()
	{
		
		$item_id=$this->input->get('item_id');
		$grn_id=$this->input->get('grn_id');
		$expire_date=$this->input->get('exp_date');
		$unit_price=$this->input->get('unit_price');
		$qty=$this->input->get('qty');
		$total_cost=$qty*$unit_price;
		$added_date_time =date('Y-m-d H:i:s');
		
			 $data=array(
			 		'item_id'=> $item_id,
					'purches_date'=> $added_date_time,
					'total_cost'=> $total_cost,
					'grn_id'=> $grn_id,
					'qty'=> $qty,
					'exp_date'=> $expire_date,
					'unit_price'=>$unit_price ,
					'unit_id'=>1 ,
					            
                    );
					
					
					$list=$this->GRN_Model->save_to_store_items($data);
					
					
					if($list==1)
					{
						$response = array(
		
		'status'=>1,
		'message'=>"Succesfully Added"
		
		
		);
	
						
		}
		else
		{
				$response = array(
		
		'status'=>0,
		'message'=>"stock update fail"
		
		
		);
			
			
		}
					
					
						echo json_encode($response);
					
		 
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function index()
	
	{ 
		
		
		if($this->session->userdata('ss_status'))
		 		{
					
					
					 if ($this->session->userdata('ss_user_level') == 2 ||$this->session->userdata('ss_user_level') == 1) 
					 {
   						
						$this->load->view('initial_order');
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
				}
		
		
	}
	

	
	
	
	
	function grn_save()
	{
		
		$query   		= $this->GRN_Model->get_next_ref_no_grn();
        $result  		= $query->row();
        $reference_no		= sprintf("GRN%05d", $result->id+1);
		
		$warehouse_id=1;
		$added_date_time =date('Y-m-d H:i:s');
		$po_id=$this->input->post('po_id');
		$supplier_invoice_number=$this->input->post('supplier_invoice_number');
		
		
		
		$error='';
		
		if(!$error)
		{
		$data=array(
		
			
			'po_id'=> $po_id,
			'suppier_invoice_no'=> $supplier_invoice_number,
			'grn_referance_no'=>$reference_no,
			'warehouse_id'=>$warehouse_id,
			'grn_date_time'=>$added_date_time,
			'status'=>0,			
			'person_id'=>$this->session->userdata('ss_user_level')
			
			);
			
			$result=$this->GRN_Model->update_po_master($po_id);
			$_insert=$this->GRN_Model->save_grn_master($data);
			$status=1;
			$disMsg='GRN successfully added';
			
			
			$row=$this->input->post('row');
			$rowCount=$this->input->post('rowCount');
			$data_items =array();
			
			for($i=1; $i<=$rowCount; $i++){
				
				if(isset($row[$i]['product_id'][0]))
				{					
				$data_item=array(
					
					'grn_id'=>$_insert,
					'item_id'=>$row[$i]['product_id'][0],
					'unit_price'=>$row[$i]['unit_price'][0],
					'received_qty'=>$row[$i]['qty'][0],
					
				);
				$this->GRN_Model->save_grn_items($data_item);
				$itemid=$this->db->insert_id();
				
				
				}
			}			
			 	
			
			
		}else {
			$status=0;
			
			$disMsg='Please select these before adding any product:'.$disMsg;
		}	
		
		 $response = array(
		
		'status'=>1,
		'message'=>$disMsg
		
		
		);
		echo json_encode($response);
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
