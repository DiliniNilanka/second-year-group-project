<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class restaurant_mini_store_order_controller extends CI_Controller {

  public function __construct(){
    parent::__construct();

    $this->load->model('Stock_Model');
    $this->load->library('form_validation');
    $this->load->model('Catogory_Model');
    $this->load->model('Unit_Model');
    $this->load->model('restaurant_mini_store_model');
    
    if($this->session->userdata('ss_status')){}

    else{
      header('Refresh: 0;url='.base_url('user_authentication'));
      
    }
    
  }



function initial_order_save()
  {
    
    $query      = $this->restaurant_mini_store_model->get_next_ref_no_initial_order();
        $result     = $query->row();
        $reference_no   = sprintf("IO%05d", $result->id+1);
    
    $warehouse_id=3;
    $added_date_time =date('Y-m-d H:i:s');
    
    
    
    $error='';
    
    if(!$error)
    {
    $data=array(
    
      
      
      'order_ref_number'=>$reference_no,
      'warehouse_id'=>$warehouse_id,
      'entered_date'=>$added_date_time,
      'status'=>0,      
      'entered_person_id'=>$this->session->userdata('ss_user_id')
      
      );
      $_insert=$this->restaurant_mini_store_model->save_initial_order_master($data);
      $status=1;
      $disMsg='Order successfully added';
      
      
      $row=$this->input->post('row');
      $rowCount=$this->input->post('rowCount');
      $data_items =array();
      
      for($i=1; $i<=$rowCount; $i++){
        
        if(isset($row[$i]['product_id'][0]))
        {         
        $data_item=array(
          
          'initial_order_id'=>$_insert,
          'item_id'=>$row[$i]['product_id'][0],
          'required_qry'=>$row[$i]['qty'][0],
          
        );
        $this->restaurant_mini_store_model->save_initial_order_items($data_item);
        $itemid=$this->db->insert_id();
        
        
        }
      }     
        
      
      
    }else {
      $status=0;
      
      $disMsg='Please select these before adding any product:'.$disMsg;
    } 
    
     $response = array(
    
    'status'=>1,
    'message'=>$disMsg
    
    
    );
    echo json_encode($response);
    
    
    
    
    
    
    
  }

  
  public function index(){ 
    
    
    if($this->session->userdata('ss_status')){
          
          
           if ($this->session->userdata('ss_user_level') == 3 || $this->session->userdata('ss_user_level') == 1){
              
            $this->load->view('res_min_str_crt_order');
            /*$this->load->model('restaurant_mini_store_model');
        $data['query'] = $this->restaurant_mini_store_model->get_all_store_item();
        $this->load->view('res_mini_str_modified', $data);*/
           
           } 
           else{
            header('Refresh: 0;url='.base_url('user_authentication/logout')); 
           }          
          
          
    }
    
  }


  public function res_crt_man_order(){ 
    
    
    if($this->session->userdata('ss_status')){
          
          
           if ($this->session->userdata('ss_user_level') == 3 || $this->session->userdata('ss_user_level') == 1){
              
            $this->load->view('res_min_str_crt_man_order');
            /*$this->load->model('restaurant_mini_store_model');
        $data['query'] = $this->restaurant_mini_store_model->get_all_store_item();
        $this->load->view('res_mini_str_modified', $data);*/
           
           } 
           else{
            header('Refresh: 0;url='.base_url('user_authentication/logout')); 
           }          
          
          
    }
    
  }

  public function get_all_item(){

    $list=$this->restaurant_mini_store_model->get_all_store_item();
    //print_r($list);
    $data=array();
    $temp='';
    
    foreach ($list as $row){

      $nested=array();
      $nested[]=$row['item_code'];
      $nested[]=$row['item_name'];
      $nested[]=$row['brand_id'];
      $nested[]=$row['item_catogory'];
      $nested[]=$row['critical_level'];
      $nested[]=$row['max_level'];
      $actdes='';
      $actdes =$actdes. '<button class="btn btn-primary" data-title="Edit" data-toggle="modal" data-target="#edit" ><i class="icon_plus_alt2"></i></button>';
      $nested[] =$actdes; 
      $data[]=$nested;
      
    }


    $json_data = array( 'data'=>$data );
    
    echo json_encode($json_data); 
    
  }

  public function get_product_suggestion()
  {
    
    $term=$this->input->get('term');
    
    $list=$this->restaurant_mini_store_model->get_product_suggestion($term);
    $in_type=$this->input->get('t');
    
    $json=array();
    
    foreach ($list as $row)
    {
     $product_id=$row['id'];
     $product_code =$row['item_code'];
     $product_name=$row['item_name'];
    
    $item_stock =$this->restaurant_mini_store_model->check_available_qty($product_id);
    
    
     $json_itm=array(
          'id'=>  $product_id,
          'product_id'=> $product_id,
          'product_code'=> $product_code,
          'product_name'=> $product_name,
          'product_qty'=> $item_stock['qty'],
          'product_part_no'=> 0,
          'item_cost'=> 0,
          'product_oem_part_number'=> 0,
                    'value'=> $row['item_name']." (".$row['item_code'].")" ,
                    'label'=> $row['item_name']." (".$row['item_code'].")"
          
          
          );
    
    array_push($json,$json_itm);
            
    }   
    echo json_encode($json);    
    

    
  }

  function get_cretical_items()
  
  {
  
                 
    $list=$this->restaurant_mini_store_model->get_all_store_item();
    
    $json=array();
  
    
    foreach ($list as $row)
    
    {
      
      if($row['current_q']<=$row['critical_level']  &&  $row['critical_level']>0)
      {

       $json_itm=array(
          'item_code'=> $row['item_code'],
          'item_name'=> $row['item_name'],
          'stock_qty'=> $row['current_q'],
          'req_qty'=> $row['re_order_qty'],
          'unit_price'=>$row['unit_price'] ,
                      
                    );
    
    array_push($json,$json_itm);
      
      }
        
    }
    
    echo json_encode($json);  
  
  
  
  }

 

}