<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Rest_Issue_Items_Cntrl extends CI_Controller {

	public function __construct() {
		parent::__construct();
			$this->load->model('rest_issue_items_model');
		}

	public function index() {
		
		
		$this->load->view('rest_issue_items');
		
		}
	
	public function view_table(){
		$result = $this->rest_issue_items_model->show_all_data();
		if ($result != false) {
			return $result;
			} else {
			return 'Database is empty !';
			}
		}

	public function select_by_id() {
		$id = $this->input->post('get_item');
		if ($id != "") {
			$result = $this->rest_issue_items_model->show_data_by_id($id);
			if ($result != false) {
				$data['result_display'] = $result;
			} else {
				$data['result_display'] = "No record found !";
			}
		} else {
			$data = array(
				'id_error_message' => "Id field is required"
				);
			}
	
		

	
		$this->load->view('rest_issue_items', $data);
		
	}

	public function add_item() {

				//Setting values for tabel columns
				$dataset = array(
						'item_id' => $this->input->post('item_id'),
						'item_name' => $this->input->post('item_name'),
						'quantity' => $this->input->post('quantity')
				);

				 $this->rest_issue_items_model->insert_selected_items($dataset);
				 


				 $data['order_tbl'] = $this->rest_issue_items_model->get_selected_items();

				
				 $this->load->view('rest_issue_items', $data);
			


				 

	}


	public function allocate_items() {

//------------------------------------------
		date_default_timezone_set('Asia/Colombo');
		$ss_user_id = $this->session->userdata('ss_user_id');
		$ss_name = $this->session->userdata('ss_user_username');
		$day = date('F jS Y');
		$time = date('h:i:s a');
		$details = '';
		$day_number = date('j');

//-------------------------------------------



		$data = $this->rest_issue_items_model->get_selected_items();

		//print_r($data);
		foreach ($data as $value) {
			$W = $value->item_id;
			$X = $value->quantity;
		
		

		$this->rest_issue_items_model->allocate_and_update($W,$X);
		}

//----------------------------------------------


		// $details = implode(",", $data);
		// echo $details;
		

		foreach ($data as $value) {
			$a = $value->item_id;
			$details = $details . " " . trim($a);
			$b = $value->item_name;
			$details = $details . "- " . trim($b);
			$c = $value->quantity;
			$details = $details . "- " . trim($c) . ",";


			// var_dump($value->item_id);
			// var_dump($value->item_name);

		}
		//echo $details;

		$dataset = array(

						'user_id' => $ss_user_id,
						'user_name' => $ss_name,
						'details' => $details,
						'date' => $day,
						'time' => $time,
						'day' => $day_number
				);



		//add details to log table
		$this->rest_issue_items_model->add_to_log_table($dataset);

//--------------------------------------------------------------


		$this->db->empty_table('temp_rest_issue');

		// $this->load->view('templates/header');
		// $this->load->view('rest_issue_items');
		// $this->load->view('templates/footer');

		redirect('/rest_issue_items_cntrl', 'refresh');





	}

	public function get_item_name() {

			$keyword=$this->input->post('keyword');
       		$data=$this->rest_issue_items_model->get_item_by_name($keyword);        
       		echo json_encode($data);



	}







}