<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Kitchen_Issue_Log_Cntrl extends CI_Controller {

	public function __construct() {
		parent::__construct();
			$this->load->model('kitchen_issue_log_model');
		}

	public function index() {

		$data['log_data'] = $this->kitchen_issue_log_model->select_log_data();

		
		$this->load->view('kitchen_issue_log_view',$data);
		


	}

	public function get_log_by_search() {

		$id = $this->input->post('day');


			$result = $this->kitchen_issue_log_model->get_data($id);
			if ($result != false) {
				$data['log_data'] = $result;
			} else {
				$data['log_data'] = "No record found !";
			}
		 
		

	
		$this->load->view('kitchen_issue_log_view', $data);
		
	

	}

	public function get_log_date() {

			$keyword=$this->input->post('keyword');
       		$data=$this->kitchen_issue_log_model->get_date($keyword);        
       		echo json_encode($data);



	}

}