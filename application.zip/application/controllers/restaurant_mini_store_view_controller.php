<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class restaurant_mini_store_view_controller extends CI_Controller {

  public function __construct(){
    parent::__construct();

    $this->load->model('Stock_Model');
    $this->load->library('form_validation');
    $this->load->model('Catogory_Model');
    $this->load->model('Unit_Model');
    $this->load->model('restaurant_mini_store_model');
    
    if($this->session->userdata('ss_status')){}

    else{
      header('Refresh: 0;url='.base_url('user_authentication'));
      
    }
    
  }
  
  public function index(){ 
    
    
    if($this->session->userdata('ss_status')){
          
          
           if ($this->session->userdata('ss_user_level') == 3 || $this->session->userdata('ss_user_level') == 1){
              
            $this->load->view('restaurant_mini_store_view');
           
           } 
           else{
            header('Refresh: 0;url='.base_url('user_authentication/logout')); 
           }          
          
          
    }
    
    
  }

  public function get_all_item(){

    $list=$this->restaurant_mini_store_model->get_all_store_item();
    //print_r($list);
    $data=array();
    $temp='';
    
    foreach ($list as $row){

      $nested=array();
      $nested[]=$row['item_code'];
      $nested[]=$row['item_name'];
      $nested[]=$row['brand_id'];
      $nested[]=$row['item_catogory'];
      $nested[]=$row['critical_level'];
      $nested[]=$row['max_level'];
      $data[]=$nested;
      
    }

    
    $json_data = array( 'data'=>$data );
    
    echo json_encode($json_data); 
    
  }

}  