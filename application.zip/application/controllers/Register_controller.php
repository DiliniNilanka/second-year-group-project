<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_controller extends CI_Controller
{

    function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Register_model');
    }

    public function index()
    {
        $this->load->view('Register_view');
    }

    

    public function add_user() {


       
        if($this->input->post('add')){
            
            

            $password = $this->input->post('password');
            $encripted_password = hash('sha512', $password);
            if($this->input->post('position') == 'Admin') {
                $lvl_name = 'admin';
                $lvl = 1;
            }
            elseif ($this->input->post('position') == 'Store Manager') {
                $lvl_name = 'store';
                 $lvl = 2;
            }
            elseif ($this->input->post('position') == 'Restaurant Head') {
                $lvl_name = 'restaurant';
                 $lvl = 3;
            }
            elseif ($this->input->post('position') == 'Assistant Restaurant Head') {
                $lvl_name = 'restaurant';
                 $lvl = 3;
            }
            elseif ($this->input->post('position') == 'Head Chef'  || $this->input->post('position') == 'Assistant Head Chef') {
                $lvl_name = 'kitchen';
                 $lvl = 4;
            }


            $userData = array(
                

                'first_name' => $this->input->post('firstname'),
                'last_name' => $this->input->post('lastname'),
                'email_address' => $this->input->post('email'),
                'user_name' => $this->input->post('username'),
                'password' => $encripted_password,
                'user_level' => $this->input->post(''),
                'user_id' => $this->input->post('userid'),
                'level_name' => $lvl_name,
                'user_level' =>   $lvl,
                'position' => $this->input->post('position'),
                'group_id' => 1,
                'is_deleted' => 0,
                'status' => 1

            );
           

            
              $this->Register_model->insert($userData);
                
            
        }
        
       
        $this->load->view('Register_view');



    }
}