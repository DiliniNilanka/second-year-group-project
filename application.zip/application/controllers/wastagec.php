<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wastagec extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('date');
		$this->load->model('Wastagem');
		
	}
	public function index(){
		$this->load->view('wastage_list');
	}
	
	public function get_expire_items_con(){
	
	  	$cur_date=date("Y-m-d");
		$list=$this->Wastagem->get_expire_items($cur_date);
		$data=array();
		
		
		foreach ($list as $row)
		
		{
			$nested=array();
			
			$current_qty=$row['qty'];
			
			$nested[]=$row['id'];
			$nested[]=$row['item_name']." / ".$row['item_code']."<input type='hidden' align='center' name='item_id' id= p_pid_". $row['id']." value ='". $row['item_id']."'  class='form-control  text-right' required> <input type='hidden' align='center' name='unit_price' id=p_unip_".$row['id']." value ='". $row['unit_price']."'  class='form-control  text-right' required>";
			
			
			
		    
			$nested[]="<input type='text' align='center' name='expdate' id= p_". $row['id']." value ='".$row['exp_date']."'  class='form-control datetime text-right' onclick='set_date(".$row['id'].")'  readonly='readonly'>";
			
			$nested[]="<input type='text' align='center' name='recived_qty' id= pqty_". $row['id']." value ='".$current_qty."'  class='form-control  text-right' required'>";
		
		
		
		$nested[]="
		
		<div class = 'btn-group' onClick = update_stock(".$row['id'] .")> <a title = '' class = 'btn btn-primary btn-xs' data-original-title = 'Add' > <i class = 'fa fa-money' > </i> <span class = 'hidden-sm hidden-xs' > Add to wastage </span></a>
</div> 
		
	
	
						";
	
				
		
							
			
	       
							
							
				
			$data[]=$nested;
	
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
		
		
	}
	
	
	function update_qty_to_store_items()
	{
		
		$item_id=$this->input->get('item_id');
		$id=$this->input->get('id');
		$expire_date=$this->input->get('exp_date');
		$unit_price=$this->input->get('unit_price');
		$qty=$this->input->get('qty');
		$total_cost=$qty*$unit_price;
		$added_date_time =date('Y-m-d H:i:s');
		
			 $data=array(
			 		'wastage'=> 1,
					'wastage_qty'=> $qty,
					'tranfer_date'=>$added_date_time,
					'tranfer_by'=>$this->session->userdata('ss_user_level')
					            
                    );
					
					
					$list=$this->Wastagem->upade_stock($id,$data);
					
					
					if($list==1)
					{
						$response = array(
		
		'status'=>1,
		'message'=>"Succesfully Added"
		
		
		);
	
						
		}
		else
		{
				$response = array(
		
		'status'=>0,
		'message'=>"stock update fail"
		
		
		);
			
			
		}
					
					
						echo json_encode($response);
					
		 
		
		
	}
	
	
	
	

	
}
?>