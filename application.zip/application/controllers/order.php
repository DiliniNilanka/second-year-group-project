<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->model('Stock_Model');
		$this->load->library('form_validation');
		$this->load->model('Catogory_Model');
		$this->load->model('Unit_Model');
		$this->load->model('Order_Model');
		
		
		if($this->session->userdata('ss_status'))
		 		{
			
			
		}
		else
		{
			header('Refresh: 0;url='.base_url('user_authentication'));
			
		}
		 
		 
		 
	 
		
	}
	
	public function get_product_suggestion()
	{
		
		$term=$this->input->get('term');
		
		$list=$this->Stock_Model->get_product_suggestion($term);
		$in_type=$this->input->get('t');
		
		$json=array();
		
		foreach ($list as $row)
		{
		 $product_id=$row['id'];
		 $product_code =$row['item_code'];
		 $product_name=$row['item_name'];
		
		$item_stock =$this->Stock_Model->check_available_qty($product_id);
		
		
		 $json_itm=array(
			 		'id'=>  $product_id,
					'product_id'=> $product_id,
					'product_code'=> $product_code,
					'product_name'=> $product_name,
					'product_qty'=> $item_stock['qty'],
					'product_part_no'=> 0,
					'item_cost'=> 0,
					'product_oem_part_number'=> 0,
                    'value'=> $row['item_name']." (".$row['item_code'].")" ,
                    'label'=> $row['item_name']." (".$row['item_code'].")"
					
					
					);
		
		array_push($json,$json_itm);
						
		}		
		echo json_encode($json);		
		

		
	}
	
	public function get_product_suggestion_purches_order()
	{
		
		$term=$this->input->get('term');
		
		$list=$this->Stock_Model->get_product_suggestion($term);
		$in_type=$this->input->get('t');
		
		$json=array();
		
		foreach ($list as $row)
		{
		 $product_id=$row['id'];
		 $product_code =$row['item_code'];
		 $product_name=$row['item_name'];
		 $unit_price=$row['unit_price'];
		
		$item_stock =$this->Stock_Model->check_available_qty($product_id);
		
		if($item_stock['qty']>0)
		{
		 $onhand = $item_stock['qty'];
		}
		else
		{
		 $onhand=0;	
		}
		
		 $json_itm=array(
			 		'id'=>  $product_id,
					'product_id'=> $product_id,
					'product_code'=> $product_code,
					'product_name'=> $product_name,
					'product_qty'=>  $unit_price,
					'product_part_no'=> 0,
					'item_cost'=> 0,
					'product_oem_part_number'=> 0,
                    'value'=> $row['item_name']." (".$row['item_code'].")" ,
                    'label'=> $row['item_name']." (".$row['item_code'].")"." on hand Qty ".$onhand
					
					
					);
		
		array_push($json,$json_itm);
						
		}		
		echo json_encode($json);		
		

		
	}
	
	
	
	
	function initial_order_save()
	{
		
		$query   		= $this->Order_Model->get_next_ref_no_initial_order();
        $result  		= $query->row();
        $reference_no		= sprintf("IO%05d", $result->id+1);
		
		$warehouse_id=1;
		$added_date_time =date('Y-m-d H:i:s');
		
		
		
		$error='';
		
		if(!$error)
		{
		$data=array(
		
			
			
			'order_ref_number'=>$reference_no,
			'warehouse_id'=>$warehouse_id,
			'entered_date'=>$added_date_time,
			'status'=>0,			
			'entered_person_id'=>$this->session->userdata('ss_user_level')
			
			);
			$_insert=$this->Order_Model->save_initial_order_master($data);
			$status=1;
			$disMsg='Order successfully added';
			
			
			$row=$this->input->post('row');
			$rowCount=$this->input->post('rowCount');
			$data_items =array();
			
			for($i=1; $i<=$rowCount; $i++){
				
				if(isset($row[$i]['product_id'][0]))
				{					
				$data_item=array(
					
					'initial_order_id'=>$_insert,
					'item_id'=>$row[$i]['product_id'][0],
					'required_qry'=>$row[$i]['qty'][0],
					'supplier_id'=>$row[$i]['item_cost'][0],
					
					
					
				);
				$this->Order_Model->save_initial_order_items($data_item);
				$itemid=$this->db->insert_id();
				
				
				}
			}			
			 	
			
			
		}else {
			$status=0;
			
			$disMsg='Please select these before adding any product:'.$disMsg;
		}	
		
		 $response = array(
		
		'status'=>1,
		'message'=>$disMsg
		
		
		);
		echo json_encode($response);
		
		
		
		
		
		
		
	}
	
	function po_deatils_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 || $this->session->userdata('ss_user_level') == 1) 
					 {
						 
						 $id= $this->input->get('id');	
						 
						 $data['po_master_details']=$this->Order_Model->get_po_master_details($id);
						 
						  $data['po_items_details']=$this->Order_Model->get_po_items_details($id);
						 
						
   						
						$this->load->view('view_perches_order',$data);
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
  }
	
	
	function po_list_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 || $this->session->userdata('ss_user_level') == 1)
					 {
   						
						$this->load->view('po_list_view');
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
  }
  
  function initial_order_list_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 || $this->session->userdata('ss_user_level') == 1) 
					 {
   						
						$this->load->view('order_list');
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
  }
  
  
  	public function list_po()
	{
		
		$list=$this->Order_Model->get_all_po();
		//print_r($list);
		$data=array();
		$temp='';
		
		foreach ($list as $row)
		
		{
			$nested=array();
			
	

			$nested[]=$row['id'];
			$nested[]=$row['PO_referance_no'];
			$nested[]=$row['po_order_date'];
			$nested[]=$row['warehouse_name'];
			$nested[]=$row['username'];
		    
			$status="";
			if($row['approval_status']==0)
			{
				$status="Pending";
			}
			else{
			if($row['approval_status']==1)
			{
				$status="Received";
				
			}
			else
			{
				$status="Rejected";
			}
			
			
			}
			
			$nested[]=$status;
			
			$actdes='';
	        $actdes =$actdes. '<div class="btn-group text-left">
                            <button data-toggle="dropdown" class="btn btn-default btn-xs btn-primary dropdown-toggle" type="button">Actions <span class="caret"></span></button>
                            <ul role="menu" class="dropdown-menu pull-right">
                            <li><a href="'.base_url('order/po_deatils_view').'?id='.$row['id'].'"><i class="fa fa-file-text-o"></i> view Purches order </a></li>
							';
							
							if($row['approval_status']==0)
			{
				 $actdes = $actdes.' <li><a href="'.base_url('grn/grn_purches_order').'?id='.$row['id'].'"><i class="fa fa-file-text-o"></i> GRN </a></li>
							';
			}
						
                       
				if($row['approval_status']==0)
			{		
						$actdes = $actdes.'	
                            <li><a onclick=" print_barcode('.$temp.'); return false;" href="#"><i class="fa fa-print"></i> Reject order</a></li>
                            
                            </ul></div>';
							
			}
			else
			{
				$actdes = $actdes.'	</ul></div>';
				
			}
							
					$nested[] =$actdes;	
	       
							
							
				
			$data[]=$nested;
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
		
		
		
		
		
		
		
	}
		
		
		

	
	
	public function list_order()
	{
		
		$list=$this->Order_Model->get_all_initial_orders();
		//print_r($list);
		$data=array();
		$temp='';
		
		foreach ($list as $row)
		
		{
			$nested=array();
			
	

			$nested[]=$row['id'];
			$nested[]=$row['order_ref_number'];
			$nested[]=$row['entered_date'];
			$nested[]=$row['warehouse_name'];
			$nested[]=$row['username'];
		    
			$status="";
			if($row['status']==0)
			{
				$status="Pending";
			}
			else{
			if($row['status']==1)
			{
				$status="Approved";
				
			}
			else
			{
				$status="Rejected";
			}
			
			
			}
			
			$nested[]=$status;
			
			$actdes='';
	        $actdes =$actdes. '<div class="btn-group text-left">
                            <button data-toggle="dropdown" class="btn btn-default btn-xs btn-primary dropdown-toggle" type="button">Actions <span class="caret"></span></button>
                            <ul role="menu" class="dropdown-menu pull-right">
                            <li><a href="'.base_url('order/generate_purches_order_view').'?id='.$row['id'].'"><i class="fa fa-file-text-o"></i> Create purches order </a></li>
							';
						
                       
						
						$actdes = $actdes.'	
                            <li><a onclick=" print_barcode('.$temp.'); return false;" href="#"><i class="fa fa-print"></i> Reject order</a></li>
                            
                            </ul></div>';
							
					$nested[] =$actdes;	
	       
							
							
				
			$data[]=$nested;
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
		
		
		
		
		
		
		
	}
	
	
	function generate_purches_order()
	
	{
	
		$id= $this->input->get('id');	
		$sup_id=$this->input->get('supplier_id');            						 
		$list=$this->Order_Model->get_all_initial_orders_items($id,$sup_id);
		
		$json=array();
	
		
		foreach ($list as $row)
		
		{
			
			
	

			 $json_itm=array(
			 		'item_id'=> $row['item_id'],
					'item_name'=> $row['item_name'],
					'item_code'=> $row['item_code'],
					'req_qty'=> $row['required_qry'],
					'unit_price'=>$row['unit_price'] ,
					            
                    );
		
		array_push($json,$json_itm);
						
				
		}
		
		echo json_encode($json);	
	
	
	
	}
	
	
	function get_cretical_items()
	
	{
	
								 
		$list=$this->Order_Model->get_all_store_item();
		
		$json=array();
	
		
		foreach ($list as $row)
		
		{
			
			if($row['qty']<=$row['critical_level']&& $row['critical_level']>0)
			{

			 $json_itm=array(
			 		'item_id'=> $row['id'],
					'item_name'=> $row['item_name'],
					'item_code'=> $row['item_code'],
					'req_qty'=> $row['re_order_qty'],
					'unit_price'=>$row['qty'] ,
					'supplier_id'=>$row['supplier_id'] ,
					            
                    );
		
		array_push($json,$json_itm);
			
			}
				
		}
		
		echo json_encode($json);	
	
	
	
	}
	
	
	
	function generate_purches_order_view()
	{
		
		 if ($this->session->userdata('ss_user_level') == 2 ||$this->session->userdata('ss_user_level') == 1) 
					 {
			
			
						$data['id']= $this->input->get('id');
						
						$data['supllier_list']=$this->Order_Model->get_relevent_suplier($data['id']);
						$this->load->view('create_purches_order',$data);
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }			
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function index()
	
	{ 
		
		
		if($this->session->userdata('ss_status'))
		 		{
					
					
					 if ($this->session->userdata('ss_user_level') == 2 || $this->session->userdata('ss_user_level') == 1)  
					 {
   						
						$this->load->view('initial_order');
					 
					 } 
					 else
					 {
						header('Refresh: 0;url='.base_url('user_authentication/logout')); 
					 }					
					
					
				}
		
		
	}
	

	
	public function get_all_item()
	
	{
		$list=$this->Stock_Model->get_all_store_item();
		//print_r($list);
		$data=array();
		$temp='';
		
		foreach ($list as $row)
		
		{
			$nested=array();
			
	

			$nested[]=$row['item_code'];
			$nested[]=$row['item_name'];
			$nested[]=$row['brand_name'];
			$nested[]=$row['category_name'];
			$nested[]=$row['unit_name'];
			$nested[]=$row['qty'];
			$nested[]=$row['critical_level'];
			$order_btn='  <button class="btn btn-primary"  id="order_btn">order</button>';
	       
							
							$input=' <input type="text" id="re_order_qty" class="form-control" name="re_order_qty">';
							
					$nested[] =$input;	
					//$nested[] =$order_btn;	
			$data[]=$nested;
	
			
		}
		
		$json_data = array( 'data'=>$data );
		
		echo json_encode($json_data); 
		
	}
	
	
	
	
	
	public function save_item()
	{
		$query   		= $this->Stock_Model->get_next_ref_no_add_item();
        $result  		= $query->row();
        $reference_no		= sprintf("PD%05d", $result->id+1);
	
    
        $this->form_validation->set_rules('item_name', 'Item Name', 'required');
      
        $this->form_validation->set_rules('product_price', 'Unit Price', 'required');
       
        $this->form_validation->set_rules('alert_quty', 'alert quty', 'required');
		



        if ($this->form_validation->run() == FALSE)
        {
           $st = array('status' =>0,'validation' => validation_errors());
           echo json_encode($st);
        }
        else
        {
        	$product_name 			= $this->input->post('item_name');
        	$category 	  			= $this->input->post('category');
        	$subcategory  			= $this->input->post('subcategory');
        	$brand 					= $this->input->post('brand');
			$unit 		  			= $this->input->post('unit');
			$product_price 			= $this->input->post('product_price');
			$alert_quty 			= $this->input->post('alert_quty');
			 $product_max_qty=$this->input->post('product_max_qty');
			$product_details 		= $this->input->post('product_details');
			$store_position=$this->input->post('store_position');
        	
        	
        	
        	$data=array(
			'item_name'=>$product_name,
			'item_catogory'=>$category,
			'item_code'=>$reference_no,
			'sub_catogory'=>$subcategory,			
			'brand_id'=>$brand,
			'unit_id'=>$unit,
			'critical_level'=>$alert_quty,
			'max_level'=>$product_max_qty,			
			'possion'=>$store_position,
			'unit_price'=>$product_price,
			'item_description'=>$product_details,
			
		);
        
        	
			$result=$this->Stock_Model->save_item($data);
			if($result==1)
			{
				 $response = array(
		
		'status'=>1,
		'message'=>"Item Saved"
		
		
		);
		
		echo json_encode($response);
				
				
			}
			else
			{
				 $response = array(
		
		'status'=>0,
		'message'=>"Somthing went to wrong!. please contact system administration"
		
		
		);
		
		echo json_encode($response);
				
			}
			
			
			 
		
		}
		
		
		
	}
	
	
	
	
	
	
	
	function perches_order_save()
	{
		
		$query   		= $this->Order_Model->get_next_ref_no_po_order();
        $result  		= $query->row();
        $reference_no		= sprintf("PO%05d", $result->id+1);
		
		$warehouse_id=1;
		$added_date_time =date('Y-m-d H:i:s');
		$initial_order_id=$this->input->post('initial_order_id');
		$supplier_id=$this->input->post('supplier_id');
		
		
		
		
		$error='';
		
		if(!$error)
		{
		$data=array(
		
			
			'order_id'=> $initial_order_id,
			'PO_referance_no'=>$reference_no,
			'suppier_id'=>$supplier_id,
			'warehouse_id'=>$warehouse_id,
			'po_order_date'=>$added_date_time,
			'approval_status'=>0,			
			'person_id'=>$this->session->userdata('ss_user_level')
			
			);
			
			//$result=$this->Order_Model->update_initial_order_master($initial_order_id);
			$_insert=$this->Order_Model->save_po_order_master($data);
			$status=1;
			$disMsg='PO successfully added';
			
			
			$row=$this->input->post('row');
			$rowCount=$this->input->post('rowCount');
			$data_items =array();
			
			for($i=1; $i<=$rowCount; $i++){
				
				if(isset($row[$i]['product_id'][0]))
				{					
				$data_item=array(
					
					'po_id'=>$_insert,
					'item_id'=>$row[$i]['product_id'][0],
					'unit_price'=>$row[$i]['unit_price'][0],
					'requsted_qty'=>$row[$i]['qty'][0],
					
				);
				$this->Order_Model->update_initial_order_relevent_supplier ($initial_order_id,$supplier_id);
				
				
				$this->Order_Model->save_po_order_items($data_item);
				$itemid=$this->db->insert_id();
				
				
				$count =$this->Order_Model->is_all_saved($initial_order_id);
				
				if($count==0)
				{
				$result=$this->Order_Model->update_initial_order_master($initial_order_id);	
				}
				
				
				}
			}			
			 	
			
			
		}else {
			$status=0;
			
			$disMsg='Please select these before adding any product:'.$disMsg;
		}	
		
		 $response = array(
		
		'status'=>1,
		'message'=>$disMsg
		
		
		);
		echo json_encode($response);
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
